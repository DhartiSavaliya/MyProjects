/******************************************************************************
*	Program Author: Dr. Yongming Tang for CSCI 6810 Java and the Internet	  *
*	Date: February, 2014													  *
*******************************************************************************/

import java.lang.*; //including Java packages used by this program
import javax.swing.*;
import Com.Savaliya.*;

public class LoginControl
{
   public Customer cust;
    //public MainBO mainBO;
    public String CustomerID, UserName;

	public LoginControl(String UName, String PWord) {

	Account Acct = new Account(UName, PWord);
	//public Customer cust;
	//mainBO = new MainBO();
	UserName = UName;

	String[] CustomerInfo = Acct.signIn();
		String CustomerName = CustomerInfo[0];
		String CustomerID = CustomerInfo[1];


	//System.out.println("CustomerNeWWW :" +CustomerInfo[1]);

	// String CustomerID = cust.Createprofile();

        if (!CustomerName.equals("")) {
			//MainBO mainBO = new MainBO();
           // CreateProfileBO CreateprofileBO = new CreateProfileBO(UName);
           		System.out.println("NeWWWIDDD :" +CustomerID);

           MainBO mainBO = new MainBO(UserName, CustomerName, CustomerID);
            //CreateProfileBO CreateprofileBO = new CreateProfileBO(UName,CustomerName,CustomerID);

          // System.out.println("CustomerID:" +CustomerID);
            /*if (!CustomerID.equals("")) {
              JPanel TabPanel = new TabPanel();
		}*/
	  }
         else{
            //System.out.println("fail!");
            JOptionPane.showMessageDialog(null, "Login failed because of invalid username or password.", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
