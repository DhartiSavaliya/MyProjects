import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import Com.Savaliya.*;
import Com.Savaliya.Vehicle;
import java.sql.*;


class RemoveVehiclePanel extends JPanel implements ActionListener
{
  private JButton RemoveButton;
  private JTextField LicensePlateNumberField;
 // private String LicensePlateNumber;
      private String LicensePlateNumber, Make, Year, Model, Color, TagCode,CustomerID;

 public RemoveVehiclePanel()
    {}


  public RemoveVehiclePanel(String Cus_ID)
  {

    this.RemoveButton = new JButton("Remove");

	CustomerID = Cus_ID;
			  System.out.println("PanelID : "+Cus_ID);

    this.LicensePlateNumberField = new JTextField(15);
    //this.LicensePlateNumberField.setText(this.LicensePlateNumber);
   // LicensePlateNumberField = new JTextField(15);

    //JLabel localJLabel = new JLabel("Tag Code:");
    JLabel localJLabel1 = new JLabel("LicensePlateNumber:");


    //JPanel localJPanel1 = new JPanel();
   JPanel localJPanel2 = new JPanel();

   // localJLabel1.setFont(new Font("Arial", 1, 14));
   // this.LicensePlateNumberField.setFont(new Font("Arial", 1, 14));

    localJPanel2.add(localJLabel1);
    localJPanel2.add(LicensePlateNumberField);

    this.RemoveButton.addActionListener(this);

    JPanel localJPanel3 = new JPanel();
   // localJPanel3.add(localJPanel1);
    localJPanel3.add(localJPanel2);

  //  JPanel localJPanel4 = new JPanel();
   // localJPanel4.add(localJPanel2);

    localJPanel3.add(this.RemoveButton);
    setLayout(new BorderLayout());
    //add(localJPanel3, "North");
    add(localJPanel3, "Center");
  }

 // public void actionPerformed(ActionEvent paramActionEvent)
 // {
   // String str = paramActionEvent.getActionCommand();
   public void actionPerformed(ActionEvent evt)  //event handling
       {
           //Object source = evt.getSource(); //get who generates this event
           String arg = evt.getActionCommand();

           		  System.out.println("CusIDAction : " +CustomerID);


    if (arg.equals("Remove"))
    {

         LicensePlateNumber = LicensePlateNumberField.getText(); //take actions

     //this.LicensePlateNumber = this.LicensePlateNumberField.getText();
      if (LicensePlateNumber.length() != 5)
      {
        JOptionPane.showMessageDialog(null, "Please Enter an Valid  VehicleIdNumber with Exactly 5 Characters!", "Confirmation", 1);
      }
      else
      {
		  //System.out.println("CusID : " +CustomerID);
		  //System.out.println("LPN : " +LicensePlateNumber);
		  	Vehicle V = new Vehicle(CustomerID,LicensePlateNumber);

		  	boolean v = V.removeVehicle();
		  System.out.println("IF" +v);

       // Vehicle localVehicle = new Vehicle(this.LicensePlateNumber);
        if (v) {
					  System.out.println("Vehicle Removed");

			//removeVehicleToPanel();
          JOptionPane.showMessageDialog(null, "Vehicle Removed Successfully!", "Confirmation", 1);

        } else {

          JOptionPane.showMessageDialog(null, "VIN not found!", "Confirmation", 1);
        }
      }
    }
  }

  public void removeVehicleToPanel(){

		Vehicle V = new Vehicle(CustomerID,LicensePlateNumber);
  		ResultSet rsTxns = null;
  		//rsTxns = vehicle.viewVehicles();
  		try {
  			if((rsTxns != null)){

  				//Loop through the list and add rows to Model
  				int i =0;
  				while(rsTxns.next())
  				{
  					LicensePlateNumber = rsTxns.getString("VIN");
  					//Make = rsTxns.getString("Make");
  					//Year = rsTxns.getString("Year");
  					//Model = rsTxns.getString("Model");
  					//Color = rsTxns.getString("Color");
  					//TagCode = rsTxns.getString("TagCode");


  					i++;
  				}
  			}
  		} catch(SQLException e) {
  			System.out.println("SQLException: " + e);
  			while (e != null){
  				System.out.println("SQLState: " + e.getSQLState());
  				System.out.println("Message: " + e.getMessage());
  				System.out.println("Vendor: " + e.getErrorCode());
  				e = e.getNextException();
  				System.out.println("");
  			}

  		} catch (Exception e) {
  			System.out.println("Exception: " + e);
  			e.printStackTrace ();
  		}

}
}

public class RemoveVehicleBO extends JFrame
		    {
				private RemoveVehiclePanel RV_Panel;
				private String CustomerID;
				public void RemoveVehiclePanel(String CustomerID)
				{
					setTitle("Vehicle");
					setSize(550, 350);

		         //get screen size and set the location of the frame
		         Toolkit tk = Toolkit.getDefaultToolkit();
		         Dimension d = tk.getScreenSize();
		         int screenHeight = d.height;
		         int screenWidth = d.width;
		         setLocation( screenWidth / 3, screenHeight / 4);

				   addWindowListener  (new WindowAdapter()
				   {
				   public void WindowClosing (WindowEvent e)
					   { System.exit(0);
				     }
			       });

				       RV_Panel =  new RemoveVehiclePanel(CustomerID);
				       Container contentPane = getContentPane(); //add a panel to a frame
				       contentPane.add(RV_Panel);
	    				show();
		}
//}
 public static void main(String [] args)
		    { JFrame frame = new LoginBO(); //initialize a JFrame object
		   			//frame.add(tabbedPane);
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					//frame.setSize(550,350);
					frame.setVisible(true);

		   // JFrame frame = new CreateProfileBO();
		      frame.show(); //display the frame
    }
	}
