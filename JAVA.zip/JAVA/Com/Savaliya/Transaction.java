/******************************************************************************
*	Program Author: Dharti Savaliya for project on EzPass System			      *
*	Date: February, 2020		       				      					  *
*******************************************************************************/

package Com.Savaliya;

import java.lang.*; //including Java packages used by this program
import java.sql.*;
import java.util.Vector;
import java.time.LocalDate;
import Com.Savaliya.*;

public class Transaction
{
	private String TransactionID, TagCode, TransactionDate, TollAmount, TransactionTime, TollPlaza, StartDate, EndDate, CustomerID;
	private String TollLaneNumber;
	//private float TollAmount;
	//int TollLaneNumber;

		public Transaction(String SDate, String EDate, String Cust_ID){
			StartDate = SDate;
			EndDate = EDate;
			CustomerID = Cust_ID;
			/*TransactionID = TransID;
			CustomerID = Cust_ID;
			TollAmount = TollAmt;*/
			//TollAmount = Float.parseFloat(TollAmt);
		}

		public Transaction(String TransID, String TagC, String Trans_Date,  String Trans_Time, String TollAmt, String Tollplaza, String TollLaneno, String Cust_ID){
			TransactionID = TransID;
			TagCode = TagC;
			TransactionDate = Trans_Date;
			TransactionTime = Trans_Time;
			TollAmount = TollAmt;
			TollPlaza = Tollplaza;
			TollLaneNumber = TollLaneno;
			CustomerID = Cust_ID;
		}


		public Transaction(String Cust_ID){
			CustomerID = Cust_ID;
		}


		public Transaction(){

		}

		public boolean recordTransaction(){
			boolean Recorded = false;
			//TransactionID Trans_ID = new TransactionID(Trans_ID);
			try{
							DBConnection ToDB = new DBConnection(); //Have a connection to the DB
							Connection DBConn = ToDB.openConn();
							Statement Stmt = DBConn.createStatement();
							System.out.println("Hello");
							String SQL_Command = "INSERT INTO [Transaction](TransactionID, TagCode, TransactionDate, TransactionTime, TollAmount, TollPlaza, TollLaneNumber, CustomerID) VALUES ('"+TransactionID+"', '"+TagCode+"', '"+TransactionDate+"', '"+TransactionTime+"', '"+TollAmount+"', '"+TollPlaza+"', '"+TollLaneNumber+"', '"+CustomerID+"' )";
							System.out.println("HII");
							int InsertRslt = Stmt.executeUpdate(SQL_Command);
								if (InsertRslt == 1){
									Recorded = true;
								}
							Stmt.close();
							ToDB.closeConn();
						}
						catch(java.sql.SQLException e)
									    {
												 System.out.println("SQLException: " + e);
												 while (e != null)
												 {   System.out.println("SQLState: " + e.getSQLState());
													 System.out.println("Message: " + e.getMessage());
													 System.out.println("Vendor: " + e.getErrorCode());
													 e = e.getNextException();
													 System.out.println("");
												 }
									    }
									    catch (java.lang.Exception e)
									    {
												 System.out.println("Exception: " + e);
												 e.printStackTrace ();
									    }
				    return Recorded;
				}

		public Vector ViewTransactions(String TransactionDate, String EndDate, String CustomerID){
			boolean ViewTransactions = false;
			//ResultSet rslt = null;
			Vector TransFound = new Vector();
			//TransactionID Trans_ID = new TransactionID(Trans_ID);
			try{
							DBConnection ToDB = new DBConnection(); //Have a connection to the DB
							Connection DBConn = ToDB.openConn();
							Statement Stmt = DBConn.createStatement();
							String SQL_Command = "SELECT * FROM [Transaction] WHERE CustomerID = "+CustomerID+"";
								//System.out.println(SQL_Command);

							ResultSet rslt = Stmt.executeQuery(SQL_Command);
							//System.out.println("result=" +rslt);

							ResultSetMetaData rsmd = rslt.getMetaData();
						//System.out.println("result" +rslt.next());

							while(rslt.next()){
								System.out.println("result.next");
								TransFound.addElement(ToDB.getNextRow(rslt,rsmd));
							}
							Stmt.close();
							ToDB.closeConn();
						}
						catch(java.sql.SQLException e)
									    {
												 System.out.println("SQLException: " + e);
												 while (e != null)
												 {   System.out.println("SQLState: " + e.getSQLState());
													 System.out.println("Message: " + e.getMessage());
													 System.out.println("Vendor: " + e.getErrorCode());
													 e = e.getNextException();
													 System.out.println("");
												 }
									    }
									    catch (java.lang.Exception e)
									    {
												 System.out.println("Exception: " + e);
												 e.printStackTrace ();
									    }
				    return TransFound;
				}
		}

