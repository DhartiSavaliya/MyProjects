/******************************************************************************
*	Program Author: Dr. Yongming Tang for CSCI 6810 Java and the Internet	  *
*	Date: September, 2012													  *
*******************************************************************************/

import java.io.*;
import java.util.*;
import java.lang.*;

public class TokenDemo {
	private String Str1; //instance variables
	private Vector TokensVec;
	private StringTokenizer StrTokens;

    //constructor
	public TokenDemo() {
		Str1 = new String("ABC;XYZ;123;999");
		TokensVec = new Vector();
		StrTokens = new StringTokenizer(Str1, ";");
	}
    //methods
	public void saveTokensIntoVector() {
	    while (StrTokens.hasMoreTokens()) {
			TokensVec.addElement( StrTokens.nextToken());
		}
	}
	public void outputTokens() {
		int NumOfTokens = TokensVec.size();
		System.out.println("There are " + NumOfTokens + " Tokens");
		for (int i=0; i<NumOfTokens; i++)
		    System.out.println("Token "+ i + ":" + TokensVec.get(i));
	}

	public static void main(String args[]){
		TokenDemo TD = new TokenDemo();
		TD.saveTokensIntoVector();
		TD.outputTokens();
	}
}