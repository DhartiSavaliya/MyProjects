/******************************************************************************
*	Program Author: Zarna Patel for CSCI 6810 Java and the Internet	  *
*	Date: March, 2019													  *
*******************************************************************************/

import java.awt.*;     //including Java packages used by this program
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import Dharti.Test.*;
import javax.swing.table.*;

class InboxPanel extends JPanel implements ActionListener
{
	String userName;
	private JTable InboxTable;
	private JButton refreshButton;
    Vector<String> columns = new Vector<String>();
    Vector<Vector> rows = new Vector<Vector>();
	public InboxPanel(String uName)
	{
		userName = uName;
	}

	public void Initialize()
	{
		refreshButton = new JButton("Refresh");
		columns.addElement("From");
		columns.addElement("Subject");
		columns.addElement("Message");
		columns.addElement("ReceivedOn");

		InboxTable = new JTable(rows,columns);
		InboxTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		InboxTable.setFillsViewportHeight(true);
		JScrollPane scroll = new JScrollPane(InboxTable);
		scroll.setPreferredSize(new Dimension(650,250));


		scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

		add(refreshButton);
		refreshButton.addActionListener(this);
        //setPreferredSize(new Dimension(650,350));
		add(scroll);
        showInboxEmails();
	}

	public void actionPerformed(ActionEvent evt)  //event handling
	{
		String arg = evt.getActionCommand();
		if(arg.equals("Refresh"))
		   showInboxEmails();
	}

	void showInboxEmails()
	{
		MailClient client = new MailClient();
		String mails = client.SendReceiveMessage("Inbox;"+userName);
		System.out.println("username InboxPanel:" +mails);

		if(!mails.equals("InValid") && !mails.equals(""))
		{
			rows.clear();
			String inboxmessages[] = mails.split("::");
			for(String eachMessage: inboxmessages)
			{
				Vector<String> v = new Vector<String>(Arrays.asList(eachMessage.split(";")));
				rows.addElement(v);
			}
			//Vehicle vehicle = new Vehicle();
			//rows = vehicle.GetVehicles();
			DefaultTableModel dtm = new DefaultTableModel(rows,columns);// VehicleTable.getModel();
			InboxTable.setModel(dtm);
			//VehicleTable.getColumn("Action").setCellEditor(new ButtonEditor(new JCheckBox()));
			//dtm.fireTableStructureChanged();
	    }
    }




}