
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.sql.*;

import Com.Savaliya.*;
import Com.Savaliya.EzTag;

class EzTagPanel extends JPanel implements ActionListener
{
    private JButton AddButton;
    private JTextField TagCodeField, TagTypeField, IssueDateField, CustomerIDField;
    private String TagCode, TagType, IssueDate;
    private String CustomerID;
    public EzTagPanel()
    {}

    //public PayTollManuallyPanel(String EZTagCode, String TollAmount)
    public EzTagPanel(String CustomerID)
    {
		/*Customer cust = newCustomer();
		cust.Createprofile = CustomerID;
        CustomerID = Acc.getCustomerID();*/
		//this.CustomerID = CustomerID;
        AddButton = new JButton("Add"); //initializing two button references


        TagCodeField = new JTextField(15);
        TagTypeField = new JTextField(15);
        IssueDateField = new JTextField(15);
        CustomerIDField = new JTextField(15);
        CustomerIDField.setText(CustomerID);

        //JLabel TypeLabel = new JLabel("Choose Payment Type: ");
        JLabel TagCodeLabel = new JLabel("Tag Code:");
        JLabel TagTypeLabel = new JLabel("Tag Type:");
        JLabel IssueDateLabel = new JLabel("Issue Date:");
        JLabel CustomerIDLabel = new JLabel("CustomerID:");

        JPanel TypePanel = new JPanel();
        JPanel TagCodeJPanel = new JPanel();
        JPanel TagTypeJPanel = new JPanel();
        JPanel IssueDateJPanel = new JPanel();
		JPanel CustomerIDJPanel = new JPanel();

        TagCodeJPanel.add(TagCodeLabel);
        TagCodeJPanel.add(TagCodeField);
        TagTypeJPanel.add(TagTypeLabel);
        TagTypeJPanel.add(TagTypeField);
        IssueDateJPanel.add(IssueDateLabel);
        IssueDateJPanel.add(IssueDateField);
        CustomerIDJPanel.add(CustomerIDLabel);
        CustomerIDJPanel.add(CustomerIDField);

        AddButton.addActionListener(this);
        //event listener registration
        JPanel TopPanel = new JPanel();
        TopPanel.add(TypePanel);
        TopPanel.add(TagCodeJPanel);

        JPanel CenterPanel = new JPanel();
        CenterPanel.add(TagCodeJPanel);
        CenterPanel.add(TagTypeJPanel);
        CenterPanel.add(IssueDateJPanel);
        CenterPanel.add(CustomerIDJPanel);

        CenterPanel.add(AddButton);

        setLayout(new BorderLayout());
        add(TopPanel, BorderLayout.NORTH);
        add(CenterPanel, BorderLayout.CENTER);
        //add(PayButton, BorderLayout.SOUTH);//add the one button on to this panel
    }
    public void actionPerformed(ActionEvent evt)  //event handling
    {
        //Object source = evt.getSource(); //get who generates this event
        String arg = evt.getActionCommand();

        if (arg.equals("Add")) { //determine which button is clicked
            TagCode = TagCodeField.getText(); //take actions
            TagType = TagTypeField.getText();
            IssueDate = IssueDateField.getText();
            CustomerID = CustomerIDField.getText();

            if (TagCode.length() != 6 ) {
				JOptionPane.showMessageDialog(null, "Please Enter an Valid  Tag Code Number with Exactly 6 Characters!", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
            } else {
			EzTag Ez = new EzTag(TagCode, TagType, IssueDate, CustomerID);

			if(Ez.addTag()){
				addEzTagToPanel();
				JOptionPane.showMessageDialog(null, "Tag Added Successfully!", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
				} else {
				JOptionPane.showMessageDialog(null, "Something went wrong!", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
				}
			}

		}

	}
	public void addEzTagToPanel(){

		EzTag EZ = new EzTag(CustomerID);
		ResultSet rslt = null;
		//rsTxns = vehicle.viewVehicles();
		try {
			if((rslt != null)){

				//Loop through the list and add rows to Model
				int i =0;
				while(rslt.next())
				{
					TagCode = rslt.getString("TagCode");
					TagType = rslt.getString("TagType");
					IssueDate = rslt.getString("IssueDate");
					CustomerID = rslt.getString("CustomerID");
					i++;
				}
			}
		} catch(SQLException e) {
			System.out.println("SQLException: " + e);
			while (e != null){
				System.out.println("SQLState: " + e.getSQLState());
				System.out.println("Message: " + e.getMessage());
				System.out.println("Vendor: " + e.getErrorCode());
				e = e.getNextException();
				System.out.println("");
			}

		} catch (Exception e) {
			System.out.println("Exception: " + e);
			e.printStackTrace ();
		}
}
	public class EzTagBO extends JFrame
		    {
				private EzTagPanel EZ_Panel;
				private String CustomerID;
				public void EzTagPanel(String CustomerID)
				{
					setTitle("EzTag");
					setSize(550, 350);

		         //get screen size and set the location of the frame
		         Toolkit tk = Toolkit.getDefaultToolkit();
		         Dimension d = tk.getScreenSize();
		         int screenHeight = d.height;
		         int screenWidth = d.width;
		         setLocation( screenWidth / 3, screenHeight / 4);

				   addWindowListener  (new WindowAdapter()
				   {
				   public void WindowClosing (WindowEvent e)
					   { System.exit(0);
				     }
			       });

				       EZ_Panel =  new EzTagPanel(CustomerID);
				       Container contentPane = getContentPane(); //add a panel to a frame
				       contentPane.add(EZ_Panel);
	    			   show();
		}
}
 public static void main(String [] args)
		    { JFrame frame = new LoginBO(); //initialize a JFrame object
		   			//frame.add(tabbedPane);
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					//frame.setSize(550,350);
					frame.setVisible(true);

		   // JFrame frame = new CreateProfileBO();
		      frame.show(); //display the frame
    }
	}