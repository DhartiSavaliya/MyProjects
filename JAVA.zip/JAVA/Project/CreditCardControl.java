import java.lang.*; //including Java packages used by this program
import javax.swing.*;
import java.awt.event.*;
import Com.Savaliya.*;
import Com.Savaliya.CreditCard;

class CreditCardControl
{
	public boolean addCreditCard;
    public CreditCardControl(String CardNumber, String Name, String ExpirationDate, String CVV, String CurrentBalance, String AddBalance, String CustomerID)
	{
		CreditCard C = new CreditCard(CardNumber, Name, ExpirationDate, CVV, CurrentBalance, AddBalance, CustomerID);
        addCreditCard = C.addCreditCard();
	}
}