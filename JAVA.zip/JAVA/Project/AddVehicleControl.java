import java.lang.*; //including Java packages used by this program
import javax.swing.*;
import java.awt.event.*;
import Com.Savaliya.*;



class AddVehicleControl
{
	public boolean addVehicle;
    public AddVehicleControl(String LicensePlateNumber, String Make, String Model, String Year, String Color, String TagCode, String CustomerID)
	{
		// ADD VEHICLE
		Vehicle V = new Vehicle(LicensePlateNumber, Make, Model, Year, Color, TagCode, CustomerID);
        addVehicle = V.addVehicle();
	}

		/*EzAccount CustomerEzAccount = new EzAccount(Account_Num);
		float DeductionAmt = new Float(TollAmount).floatValue();

		deductionResult = CustomerEzAccount.deductTollAmount(DeductionAmt);

		// Record Transaction
		Transactio TransactionRec = new Transactio(EZTagCode, Account_Num, TransactionDate,TransactionTime,TollAmount,TollPlazaId);
		IsTransactionRecorded = TransactionRec.sRecordTransaction();*/
}

