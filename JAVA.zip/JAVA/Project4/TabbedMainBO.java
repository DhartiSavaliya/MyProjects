
/******************************************************************************
*	Program Author: Zarna Patel for CSCI 6810 Java and the Internet	  *
*	Date: March, 2019													  *
*******************************************************************************/

import java.awt.*;     //including Java packages used by this program
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import Dharti.Test.*;

class MailPanel extends JPanel implements ActionListener
{
	String userName;

	JButton SignOutButton,SendButton,ReplyButton,ClearButton;
	JTextField FromField,ToField,SubjectField,MessageField;
	public MailPanel(String UName)
	{
		 userName = UName;
		 //SignOutButton = new JButton("SignOut");
		 SendButton = new JButton("Send");
		 ReplyButton = new JButton("Reply");


		 //JLabel FromLabel = new JLabel("From: ");
		 JLabel ToLabel = new JLabel("To: ");
		 JLabel SubjectLabel = new JLabel("Subject: ");
		 JLabel MessageLabel = new JLabel("Message: ");

		 //FromField = new JTextField(20);
		 ToField = new JTextField(20);
		 SubjectField = new JTextField(20);
		 MessageField = new JTextField(25);

		 //JPanel FromPanel = new JPanel();
		 //FromPanel.add(FromLabel);
		 //FromPanel.add(FromField);

		 JPanel ToPanel = new JPanel();
		 ToPanel.add(ToLabel);
		 ToPanel.add(ToField);

		 JPanel SubjectPanel = new JPanel();
		 SubjectPanel.add(SubjectLabel);
		 SubjectPanel.add(SubjectField);

		 JPanel MessagePanel = new JPanel();
		 MessagePanel.add(MessageLabel);
		 MessagePanel.add(MessageField);

		 //add(FromPanel);
		 add(ToPanel);
		 add(SubjectPanel);
		 add(MessagePanel);
		 add(SendButton);

		 SendButton.addActionListener(this);

	}

	public void actionPerformed(ActionEvent evt)  //event handling
	{
		String arg = evt.getActionCommand();
        if (arg.equals("Send"))
        {
			String message = "Send;"+userName+";"+ToField.getText()+";"+SubjectField.getText()+";"+MessageField.getText()+"\n";

			MailClient client = new MailClient();
			String retMessage = client.SendReceiveMessage(message);
			if(retMessage.equals("Valid"))
				JOptionPane.showMessageDialog(null, "Message sent", "Confirmation", JOptionPane.INFORMATION_MESSAGE);

			else
			   JOptionPane.showMessageDialog(null, "Failed to sent message!", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
		}
	}
}
public class TabbedMainBO extends JFrame implements ActionListener
{
	private JTabbedPane tabbedPane;
	InboxPanel inboxPanel;
    MailPanel mailPanel;
    SentPanel sentPanel;

    JLabel UserNameLabel;
    JButton SignOutButton,SendButton,ReplyButton,ClearButton;

    JTextField FromField,ToField,SubjectField,MessageField;

    String userName;

	public TabbedMainBO(String UName, String CustomerName)
	{
		userName = UName;
	        setTitle("DNZ Email");
	        setSize(690, 500);
			//setExtendedState(Frame.MAXIMIZED_BOTH);
	         //get screen size and set the location of the frame
	         Toolkit tk = Toolkit.getDefaultToolkit();
	         Dimension d = tk.getScreenSize();
	         int screenHeight = d.height;
	         int screenWidth = d.width;
	         setLocation( screenWidth / 3, screenHeight / 4);

	         addWindowListener (new WindowAdapter()  //handle window event
	            {
			       public void windowClosing (WindowEvent e)
				                  { System.exit(0);
	               }
             });

              UserNameLabel = new JLabel(CustomerName);
              SignOutButton = new JButton("Sign Out");


              SendButton = new JButton("Send");
		      ReplyButton = new JButton("Reply");

		       //JLabel FromLabel = new JLabel("From: ");
			  JLabel ToLabel = new JLabel("To: ");
			  JLabel SubjectLabel = new JLabel("Subject: ");
			  JLabel MessageLabel = new JLabel("Message: ");

			  //FromField = new JTextField(20);
			  ToField = new JTextField(20);
			  SubjectField = new JTextField(20);
			  MessageField = new JTextField(25);

			  //JPanel FromPanel = new JPanel();
			  //FromPanel.add(FromLabel);
			  //FromPanel.add(FromField);

			  JPanel HeaderPanel = new JPanel();
			  HeaderPanel.add(UserNameLabel);
              HeaderPanel.add(SignOutButton);
              SignOutButton.addActionListener(this);


			  JPanel MessagePanel = new JPanel();
			  MessagePanel.add(ToLabel);
			  MessagePanel.add(ToField);
			  MessagePanel.add(SubjectLabel);
			  MessagePanel.add(SubjectField);
			  MessagePanel.add(MessageLabel);
			  MessagePanel.add(MessageField);
			  MessagePanel.add(SendButton);
			  SendButton.addActionListener(this);

			 //mailPanel = new MailPanel(UName);
			 inboxPanel = new InboxPanel(UName);
			 inboxPanel.Initialize();
			 sentPanel = new SentPanel(UName);
			 sentPanel.Initialize();
             tabbedPane = new JTabbedPane(); //initialize a JTabbedPane object

//add panel to the tabbed panel
			 tabbedPane.addTab("Inbox", inboxPanel); //add GUI components to Tabbed Pane
			 tabbedPane.setSelectedIndex(0);
			 tabbedPane.addTab("Sent", sentPanel);
 			 //tabbedPane.addTab("Inquire Transactions", InquireTran_Panel);
			 //tabbedPane.addTab("Change Password", ChangePassword_Panel);

			 //Container contentPane = getContentPane();
			 //add whole tabbed panel in main window
			 JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, HeaderPanel,tabbedPane);
			 JSplitPane splitPane1 = new JSplitPane(JSplitPane.VERTICAL_SPLIT);//, splitPane, mailPanel);
			 splitPane1.setTopComponent(splitPane);
			 splitPane1.setBottomComponent(MessagePanel);
			 //JSplitPane splitPane2 = new JSplitPane(JSplitPane.VERTICAL_SPLIT, splitPane1, MessagePanel);
			 add(splitPane1);
			 show();
	}

	public void actionPerformed(ActionEvent evt)  //event handling
	{
		String arg = evt.getActionCommand();
		if (arg.equals("Send"))
		{
			String message = "Send;"+userName+";"+ToField.getText()+";"+SubjectField.getText()+";"+MessageField.getText()+"\n";

			MailClient client = new MailClient();
			String retMessage = client.SendReceiveMessage(message);
			if(retMessage.equals("Valid"))
			{
				sentPanel.showOutboxEmails();
				//JOptionPane.showMessageDialog(null, "Message sent", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
			}
			else
			   JOptionPane.showMessageDialog(null, "Failed to sent message!", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
		}
		if(arg.equals("Sign Out"))
		{
			System.exit(0);
		}
	}

	 public static void main(String [] args)
	    {
			JFrame frame = new TabbedMainBO("Dharti","Vishwa"); //initialize a JFrame object
	       //frame.show(); //display the frame
    }

}