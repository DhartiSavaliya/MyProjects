import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class SentPanel extends JPanel implements ActionListener
{
	private JButton SentButton;
	public SentPanel()
	{
		SentButton = new JButton("Sent");
		JPanel TopPanel = new JPanel();
		setLayout(new BorderLayout());
		add(TopPanel, BorderLayout.NORTH);
	}
	public void actionPerformed(ActionEvent evt)
	{

	}
}

public class Sent extends JFrame
{
	private SentPanel S_Panel;
	public Sent()
		{

		   setTitle("SENT");
		   setSize(200, 350);//get screen size and set the location of the frame

		   Toolkit tk = Toolkit.getDefaultToolkit();
		   Dimension d = tk.getScreenSize();
		   int screenHeight = d.height;
		   int screenWidth = d.width;
		   setBounds(100, 100, d.height, d.width);
		   setLocation( screenWidth / 3, screenHeight / 4);

			addWindowListener  (new WindowAdapter()
			 {
				 public void WindowClosing (WindowEvent e)
				 { System.exit(0);
					     }
			});

			     S_Panel =  new SentPanel();
				 Container contentPane = getContentPane(); //add a panel to a frame
		         contentPane.add(S_Panel);
			     show();

			}
		}