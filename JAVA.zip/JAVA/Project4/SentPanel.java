/******************************************************************************
*	Program Author: Zarna Patel for CSCI 6810 Java and the Internet	  *
*	Date: March, 2019													  *
*******************************************************************************/

import java.awt.*;     //including Java packages used by this program
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import Dharti.Test.*;
import javax.swing.table.*;

class SentPanel extends JPanel implements ActionListener
{
	private JTable SentTable;
	private JButton refreshButton;
    Vector<String> columns = new Vector<String>();
    Vector<Vector> rows = new Vector<Vector>();
    String userName;
	public SentPanel(String UName)
	{
		userName = UName;
	}

	public void Initialize()
	{
		refreshButton = new JButton("Refresh");
		columns.addElement("To");
		columns.addElement("Subject");
		columns.addElement("Message");
		columns.addElement("SentOn");

		SentTable = new JTable(rows,columns);
		SentTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		SentTable.setFillsViewportHeight(true);
		JScrollPane scroll = new JScrollPane(SentTable);
		scroll.setPreferredSize(new Dimension(650,250));

		scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

		add(refreshButton);
		refreshButton.addActionListener(this);
		add(scroll);
        showOutboxEmails();
	}

	public void actionPerformed(ActionEvent evt)  //event handling
	{
			String arg = evt.getActionCommand();
			if(arg.equals("Refresh"))
			   showOutboxEmails();
	}

	public void showOutboxEmails()
		{
			MailClient client = new MailClient();
			String mails = client.SendReceiveMessage("OutBox;"+userName);
			if(!mails.equals("InValid") && !mails.equals(""))
			{
				rows.clear();
				String inboxmessages[] = mails.split("::");
				for(String eachMessage: inboxmessages)
				{
					Vector<String> v = new Vector<String>(Arrays.asList(eachMessage.split(";")));
					rows.addElement(v);
				}
				//Vehicle vehicle = new Vehicle();
				//rows = vehicle.GetVehicles();
				DefaultTableModel dtm = new DefaultTableModel(rows,columns);// VehicleTable.getModel();
				SentTable.setModel(dtm);
				//VehicleTable.getColumn("Action").setCellEditor(new ButtonEditor(new JCheckBox()));
				//dtm.fireTableStructureChanged();
		    }
    }

}