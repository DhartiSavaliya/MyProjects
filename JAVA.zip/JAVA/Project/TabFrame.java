/******************************************************************************
*	Program Author: Dharti Savaliya for CSCI 6810 Java and the Internet	      *
*	Date: February, 2020													 *
*******************************************************************************/

import java.awt.*;     //including Java packages used by this program
import java.awt.event.*;
import javax.swing.*;
import Com.Savaliya.*;

class TabPanel extends JPanel
{
	private String CustomerID, UName, CustomerName;
	public TabPanel()
	{

		tabbedPane = new JTabbedPane(); // initialize a JTabbedPane object
		tabPanel_1 = new CreateProfilePanel(CustomerName,CustomerID);
		tabPanel_2 = new AddVehiclePanel(CustomerID);


		tabbedPane.addTab("Create Profile", tabPanel_1); // add GUI components to TabbedPane
		tabbedPane.addTab("Add Vehicle", tabPanel_2); // add GUI components to TabbedPane

		tabbedPane.setSelectedIndex(0);
		add(tabbedPane);


	}

	private JTabbedPane tabbedPane;
	private JPanel tabPanel_1, tabPanel_2;

}

public class TabFrame extends JFrame
{

	/*private JMenu MyAccountMenu;
	private JMenuBar MainMenuBar;
	private JMenuItem UpdatecustomerprofileMenuItem, changepasswordMenuItem, logoutMenuItem;*/

	public TabFrame()
	{
		setTitle("Table");
		setSize(500,320);


		 		/*	  MyAccountMenuBar = new JMenuBar();
					   MyAccountMenu = new JMenu("My Account"); // initializing menus
					   MyAccountMenu.setMnemonic('M');
					   UpdatecustomerprofileMenuItem = new JMenuItem("Update Customer Profile", 'U');
					   changepasswordMenuItem = new JMenuItem("change password", 'C');
			           logoutMenuItem = new JMenuItem("Logout", 'L');

			                     MyAccountMenu.add(UpdatecustomerprofileMenuItem);
					   	         MyAccountMenu.addSeparator();
					   	         MyAccountMenu.add(changepasswordMenuItem);
					   			 MyAccountMenu.addSeparator();
					   	         MyAccountMenu.add(logoutMenuItem);
					   			 MyAccountMenu.addSeparator();

					   			 setJMenuBar(MyAccountMenuBar); */


		 //get screen size and set the location of the frame
			       /*  Toolkit tk = Toolkit.getDefaultToolkit();
			         Dimension d = tk.getScreenSize();
			         int screenHeight = d.height;
			         int screenWidth = d.width;
			         setLocation( screenWidth / 3, screenHeight / 4);*/

			          Toolkit tk = Toolkit.getDefaultToolkit();
					       Dimension d = tk.getScreenSize();
					       int screenHeight = d.height;
					       int screenWidth = d.width;
					       setLocation( screenWidth / 2 - 250, screenHeight / 4);


			          addWindowListener (new WindowAdapter() //handle window event
					 	            {
					 			       public void windowClosing (WindowEvent e)
					 				                  { System.exit(0);
					 	               }
					 	            });

					 				JPanel TabPanel = new TabPanel();
					 				Container contentPane = getContentPane();
					 				contentPane.add(TabPanel);

	}
 public static void main(String [] args)
	    { JFrame frame = new TabFrame(); //initialize a JFrame object
	    		//frame.setSize(1000,500);
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setVisible(true);

	   // JFrame frame = new CreateProfileBO();
	      frame.show(); //display the frame
    }


}