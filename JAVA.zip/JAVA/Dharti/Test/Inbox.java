import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class InboxPanel extends JPanel implements ActionListener
{
	private JButton InboxButton;
	public InboxPanel()
	{
		InboxButton = new JButton("Inbox");
		JPanel TopPanel = new JPanel();
		setLayout(new BorderLayout());
		add(TopPanel, BorderLayout.NORTH);
	}
	public void actionPerformed(ActionEvent evt)
	{

	}
}

public class Inbox extends JFrame
{
	private InboxPanel IN_Panel;
	public void Inbox()
	{

	   setTitle("INBOX");
	   setSize(200, 350);//get screen size and set the location of the frame

	   Toolkit tk = Toolkit.getDefaultToolkit();
	   Dimension d = tk.getScreenSize();
	   int screenHeight = d.height;
	   int screenWidth = d.width;
	   setBounds(100, 100, d.height, d.width);
	   setLocation( screenWidth / 3, screenHeight / 4);

		addWindowListener  (new WindowAdapter()
		 {
			 public void WindowClosing (WindowEvent e)
			 { System.exit(0);
				     }
		});

		     IN_Panel =  new InboxPanel();
			 Container contentPane = getContentPane(); //add a panel to a frame
	         contentPane.add(IN_Panel);
		     show();

			}

	/*public static void main(String [] args)
	 {
		 JFrame frame = new LoginBO(); //initialize a JFrame object
		 frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		 frame.setVisible(true);

        frame.show(); //display the frame
    }*/
}