/******************************************************************************
*	Program Author: Dharti Savaliya for project on EzPass System	              *
*	Date: February, 2020				      		        				  *
*******************************************************************************/
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.sql.*;
import Com.Savaliya.*;
import Com.Savaliya.CreditCard;


class CreditCardPanel extends JPanel implements ActionListener
{
    private JButton AddButton;
    private JTextField CardNumberField, NameField, ExpirationDateField, CVVField, CustomerIDField, CurrentBalanceField, AddBalanceField;
    private String CardNumber, Name, ExpirationDate, CVV, CurrentBalance, AddBalance;
    private String CustomerID;
    public CreditCardPanel()
    {}

    public CreditCardPanel(String CustomerID, String CurrentBalance)
    {

        AddButton = new JButton("Recharge"); //initializing button reference

        CardNumberField = new JTextField(15);
        NameField = new JTextField(15);
        ExpirationDateField = new JTextField(15);
        CVVField = new JTextField(15);
        CurrentBalanceField = new JTextField(15);
        CurrentBalanceField.setText("0.0");
        AddBalanceField = new JTextField(15);
        CustomerIDField = new JTextField(15);
        CustomerIDField.setText(CustomerID);

        JLabel CardNumberLabel = new JLabel("Card Number:");
        JLabel NameLabel = new JLabel("Name on Card:");
        JLabel ExpirationDateLabel = new JLabel("EXP:");
        JLabel CVVLabel = new JLabel("CVV:");
        JLabel CurrentBalanceLabel = new JLabel("Current Balance:");
        JLabel AddBalanceLabel = new JLabel("Add Balance:");
        JLabel CustomerIDLabel = new JLabel("CustomerID:");

        JPanel TypePanel = new JPanel();

        JPanel CardNumberJPanel = new JPanel();
        JPanel NameJPanel = new JPanel();
        JPanel ExpirationDateJPanel = new JPanel();
        JPanel CVVJPanel = new JPanel();
        JPanel CurrentBalanceJPanel = new JPanel();
        JPanel AddBalanceJPanel = new JPanel();
        JPanel CustomerIDJPanel = new JPanel();

        CardNumberJPanel.add(CardNumberLabel);
        CardNumberJPanel.add(CardNumberField);
        NameJPanel.add(NameLabel);
        NameJPanel.add(NameField);
        ExpirationDateJPanel.add(ExpirationDateLabel);
        ExpirationDateJPanel.add(ExpirationDateField);
        CVVJPanel.add(CVVLabel);
        CVVJPanel.add(CVVField);
        CurrentBalanceJPanel.add(CurrentBalanceLabel);
        CurrentBalanceJPanel.add(CurrentBalanceField);
        AddBalanceJPanel.add(AddBalanceLabel);
        AddBalanceJPanel.add(AddBalanceField);
        CustomerIDJPanel.add(CustomerIDLabel);
        CustomerIDJPanel.add(CustomerIDField);

        AddButton.addActionListener(this); //event listener registration
        JPanel TopPanel = new JPanel();
        TopPanel.add(TypePanel);
        TopPanel.add(CustomerIDJPanel);
       // TopPanel.add(CardNumberJPanel);

        JPanel CenterPanel = new JPanel();
        CenterPanel.add(CustomerIDJPanel);
        CenterPanel.add(CurrentBalanceJPanel);
        CenterPanel.add(AddBalanceJPanel);
        CenterPanel.add(CardNumberJPanel);
        CenterPanel.add(NameJPanel);
        CenterPanel.add(ExpirationDateJPanel);
        CenterPanel.add(CVVJPanel);

        CenterPanel.add(AddButton);

        setLayout(new BorderLayout());
        add(TopPanel, BorderLayout.NORTH);
        add(CenterPanel, BorderLayout.CENTER);
        //add(PayButton, BorderLayout.SOUTH);//add the one button on to this panel
    }
    public void actionPerformed(ActionEvent evt)  //event handling
    {
        //Object source = evt.getSource(); //get who generates this event
        String arg = evt.getActionCommand();

        if (arg.equals("Recharge")) { //determine which button is clicked

            CardNumber = CardNumberField.getText(); //take actions
            Name = NameField.getText();
            ExpirationDate = ExpirationDateField.getText();
            CVV = CVVField.getText();
            CurrentBalance = CurrentBalanceField.getText();
            AddBalance = AddBalanceField.getText();
            CustomerID = CustomerIDField.getText();

			 if (CardNumber.length() != 10 ) {
							JOptionPane.showMessageDialog(null, "Please Enter an Valid  Card Number with Exactly 10 Characters!", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
			            } else {
						CreditCard C = new CreditCard(CardNumber, Name, ExpirationDate, CVV, CurrentBalance, AddBalance, CustomerID);

						if(C.addCreditCard()){
							addCreditCardToPanel();
							JOptionPane.showMessageDialog(null, "Your Account has been Recharged Successfully!", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
							} else {
							JOptionPane.showMessageDialog(null, "Something went wrong!", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
							}
						}

					}
	}

	public void addCreditCardToPanel(){

		CreditCard C_card = new CreditCard(CustomerID, CurrentBalance);
		ResultSet rslt = null;
		try {
			if((rslt != null)){

				//Loop through the list and add rows to Model
				int i =0;
				while(rslt.next())
				{
					CardNumber = rslt.getString("CardNumber");
					Name = rslt.getString("Name");
					ExpirationDate = rslt.getString("EXP");
					CVV = rslt.getString("CVV");
					CurrentBalance = rslt.getString("CurrentBalance");
					AddBalance = rslt.getString("Add Balance");
					i++;
				}
			}
		} catch(SQLException e) {
			System.out.println("SQLException: " + e);
			while (e != null){
				System.out.println("SQLState: " + e.getSQLState());
				System.out.println("Message: " + e.getMessage());
				System.out.println("Vendor: " + e.getErrorCode());
				e = e.getNextException();
				System.out.println("");
			}

		} catch (Exception e) {
			System.out.println("Exception: " + e);
			e.printStackTrace ();
		}
}
	public class CreditCardBO extends JFrame
		    {

				public void CreditCardPanel(String CustomerID, String CurrentBalance)
				{
					setTitle("Recharge");
					setSize(550, 350);

		         //get screen size and set the location of the frame
		         Toolkit tk = Toolkit.getDefaultToolkit();
		         Dimension d = tk.getScreenSize();
		         int screenHeight = d.height;
		         int screenWidth = d.width;
		         setLocation( screenWidth / 3, screenHeight / 4);

				   addWindowListener  (new WindowAdapter()
				   {
				   public void WindowClosing (WindowEvent e)
					   { System.exit(0);
				     }
			       });

				       JPanel CC_Panel =  new CreditCardPanel(CustomerID, CurrentBalance);
				       Container contentPane = getContentPane(); //add a panel to a frame
				       contentPane.add(CC_Panel);
	    			   show();
		}
}
 /*public static void main(String [] args)
		    { JFrame frame = new LoginBO(); //initialize a JFrame object
		   			//frame.add(tabbedPane);
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					//frame.setSize(550,350);
					frame.setVisible(true);

		   // JFrame frame = new CreateProfileBO();
		      frame.show(); //display the frame
    }*/
	}