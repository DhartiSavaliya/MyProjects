/******************************************************************************
*	Program Author: Dr. Yongming Tang for CSCI 6810 Java and the Internet	  *
*	Date: September, 2012													  *
*******************************************************************************/

package Com.Savaliya;

import java.lang.*; //including Java packages used by this program
import java.sql.*;
import java.time.LocalDate;
import Com.Savaliya.*;

public class Vehicle{

	private String LisensePlateNumber, Make, Model, Year, Color, TagCode, CustomerID;
	public  Vehicle(String LPN, String MK , String MODEL , String YEAR ,String COLR, String TGCode, String Cus_ID){

		LisensePlateNumber = LPN;
		Make = MK;
		Model = MODEL;
		Year = YEAR;
		Color = COLR;
		TagCode = TGCode;
		CustomerID = Cus_ID;
	  // System.out.println("Vehicle PlateNum: " +LisensePlateNumber);


		}
		public Vehicle(String Cust_ID){
				CustomerID = Cust_ID;

				System.out.println("Vehicle CustomerID" +CustomerID);

			}


	public Vehicle(String Cust_ID, String LPN){
		CustomerID = Cust_ID;
		LisensePlateNumber = LPN;

		System.out.println("Vehicle CustomerID" +CustomerID);
		System.out.println("Vehicle LisensePlateNumber " +LisensePlateNumber);

	}
		public Vehicle(String V_make, String V_model, String V_year, String V_color, String V_tagcode){
				Make = V_make;
				Model = V_model;
				Year = V_year;
				Color = V_color;
				TagCode = V_tagcode;
				System.out.println(Color);

			}

		public boolean addVehicle(){

			boolean done = false;
						try{
							DBConnection ToDB = new DBConnection(); //Have a connection to the DB
							Connection DBConn = ToDB.openConn();
							Statement Stmt = DBConn.createStatement();
							//System.out.println("VehicleInsertInto");
							String SQL_Command = "INSERT INTO Vehicle(LicensePlateNumber, Make, Model, Year, Color, TagCode, CustomerID) VALUES ('"+LisensePlateNumber+ "' , '" +Make+ "',  '" +Model+ "', " +Year+ ", '" +Color+ "', '" +TagCode+ "','"+CustomerID+"')";
							int InsertRslt = Stmt.executeUpdate(SQL_Command);
								if (InsertRslt == 1){
									done = true;
								}
							Stmt.close();
							ToDB.closeConn();
						}
						catch(java.sql.SQLException e)
									    {         done = false;
												 System.out.println("SQLException: " + e);
												 while (e != null)
												 {   System.out.println("SQLState: " + e.getSQLState());
													 System.out.println("Message: " + e.getMessage());
													 System.out.println("Vendor: " + e.getErrorCode());
													 e = e.getNextException();
													 System.out.println("");
												 }
									    }
									    catch (java.lang.Exception e)
									    {         done = false;
												 System.out.println("Exception: " + e);
												 e.printStackTrace ();
									    }
				    return done;

		}
		public boolean removeVehicle(){

			boolean done = false;
								try{
									DBConnection ToDB = new DBConnection(); //Have a connection to the DB
									Connection DBConn = ToDB.openConn();
									Statement Stmt = DBConn.createStatement();


									 String SQL_Command = "SELECT * FROM Vehicle WHERE CustomerID ='"+CustomerID+"'"; //SQL query command
									 ResultSet Rslt = Stmt.executeQuery(SQL_Command); //Inquire if the username exsits.
									// done = done && !Rslt.next();

									if(Rslt.next()) {

										//System.out.println("LPN : " +LisensePlateNumber);
										String SQL_Command1 = "DELETE FROM Vehicle WHERE LicensePlateNumber = '"+LisensePlateNumber+"'";
										int deleteRslt = Stmt.executeUpdate(SQL_Command1);
									    if(deleteRslt == 1){
											done = true;
												}
										Stmt.close();
										ToDB.closeConn();
										}

								}
								catch(java.sql.SQLException e)
											    {         done = false;
														 System.out.println("SQLException: " + e);
														 while (e != null)
														 {   System.out.println("SQLState: " + e.getSQLState());
															 System.out.println("Message: " + e.getMessage());
															 System.out.println("Vendor: " + e.getErrorCode());
															 e = e.getNextException();
															 System.out.println("");
														 }
											    }
											    catch (java.lang.Exception e)
											    {         done = false;
														 System.out.println("Exception: " + e);
														 e.printStackTrace ();
											    }
			    return done;

		}

		public ResultSet viewVehicle(){
					boolean done = true;
					ResultSet Rslt = null;
								try{
									DBConnection ToDB = new DBConnection(); //Have a connection to the DB
									Connection DBConn = ToDB.openConn();
									Statement Stmt = DBConn.createStatement();
									String SQL_Command = "SELECT LisencePlateNumber, Make, Model, Year, Color, TagCode FROM Vehicle WHERE CustomerID = '"+CustomerID+"'";
									Rslt = Stmt.executeQuery(SQL_Command);
									Stmt.close();
									ToDB.closeConn();
								}
								catch(java.sql.SQLException e)
											    {         done = false;
														 System.out.println("SQLException: " + e);
														 while (e != null)
														 {   System.out.println("SQLState: " + e.getSQLState());
															 System.out.println("Message: " + e.getMessage());
															 System.out.println("Vendor: " + e.getErrorCode());
															 e = e.getNextException();
															 System.out.println("");
														 }
											    }
											    catch (java.lang.Exception e)
											    {         done = false;
														 System.out.println("Exception: " + e);
														 e.printStackTrace ();
											    }
						return Rslt;
			}

}