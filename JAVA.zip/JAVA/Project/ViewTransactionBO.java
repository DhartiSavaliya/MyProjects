/******************************************************************************
*	Program Author: Dharti Savaliya for project on EzPass System	              *
*	Date: February, 2020													  *
*******************************************************************************/
import java.awt.*;     //including Java packages used by this program
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.*;
import java.util.List;
import java.sql.*;
import Com.Savaliya.*;
import Com.Savaliya.Transaction;

class ViewTransactionsPanel extends JPanel implements ActionListener
{
    private JButton ViewButton;
    private JTextField StartDateField, EndDateField, CustomerIDField;
    private String StartDate, EndDate, CustomerID;
   // private DefaultTableModel TxnTableModel;
    private JTable TransTable;

    public ViewTransactionsPanel(String StartDate,String EndDate, String CustomerID)
    {
        ViewButton = new JButton("View Transactions"); //initializing two button references

        StartDateField = new JTextField(15);
        StartDateField.setText(StartDate);
        EndDateField = new JTextField(15);
		EndDateField.setText(EndDate);
		CustomerIDField = new JTextField(15);
		CustomerIDField.setText(CustomerID);

        JLabel StartDateLabel = new JLabel("StartDate:");
        JLabel EndDateLabel = new JLabel("EndDate:");
        JLabel CustomerIDLabel = new JLabel("CustomerID:");

        JPanel StartDateJPanel = new JPanel();
        JPanel EndDateJPanel = new JPanel();
        JPanel CustomerIDJPanel = new JPanel();

		StartDateLabel.setFont(new Font("Arial", Font.BOLD, 14));
        StartDateField.setFont(new Font("Arial", Font.BOLD, 14));
        EndDateLabel.setFont(new Font("Arial", Font.BOLD, 14));
        EndDateField.setFont(new Font("Arial", Font.BOLD, 14));
		ViewButton.setFont(new Font("Arial", Font.BOLD, 14));

        StartDateJPanel.add(StartDateLabel);
        StartDateJPanel.add(StartDateField);
        EndDateJPanel.add(EndDateLabel);
        EndDateJPanel.add(EndDateField);
        CustomerIDJPanel.add(CustomerIDLabel);
        CustomerIDJPanel.add(CustomerIDField);

        ViewButton.addActionListener(this);
        //event listener registration

        JPanel TopPanel = new JPanel();
        TopPanel.add(CustomerIDJPanel);
        TopPanel.add(StartDateJPanel);
		TopPanel.add(EndDateJPanel);
		TopPanel.add(ViewButton);

        JPanel CenterPanel = new JPanel();

		// Data to be displayed in the JTable
		String[][] data = {{"", "", "", "", "", "", "", ""}};

        add(TopPanel, BorderLayout.CENTER);

    }

    public void actionPerformed(ActionEvent evt)  //event handling
	    {

	        String arg = evt.getActionCommand();

	        if (arg.equals("View Transactions")) //determine which button is clicked
				{
					 StartDate = StartDateField.getText();
					 EndDate = EndDateField.getText();
					 CustomerID = CustomerIDField.getText();
	                // TxnTableModel.setRowCount(0);

					Transaction T = new Transaction();

					Vector TransFound = T.ViewTransactions(StartDate, EndDate, CustomerID);
					Vector<String> V = new Vector<String>();//here have another Vector to have column names for the transaction table.


					V.addElement("TransactionID");
					V.addElement("TagCode");
					V.addElement("TransactionDate");
					V.addElement("TransactionTime");
					V.addElement("TollAmount");
					V.addElement("TollPlaza");
					V.addElement("TollLaneNumber");

				 TransTable = new JTable(TransFound, V); //Then initialize JTable TransTable with the two vectors. Add  TransTable to ViewTransactionPanel;
					JScrollPane scrollPane = new JScrollPane(TransTable);
					  add(scrollPane, BorderLayout.SOUTH);


		}
	}

}

public class ViewTransactionBO extends JFrame
		    {
				//private EzTagPanel EZ_Panel;
				private String CustomerID,StartDate,EndDate;
				public void EzTagPanel(String CustomerID)
				{
					setTitle("EzTag");
					setSize(600, 400);

		         //get screen size and set the location of the frame
		         Toolkit tk = Toolkit.getDefaultToolkit();
		         Dimension d = tk.getScreenSize();
		         int screenHeight = d.height;
		         int screenWidth = d.width;
		         setLocation( screenWidth / 3, screenHeight / 4);

				   addWindowListener  (new WindowAdapter()
				   {
				   public void WindowClosing (WindowEvent e)
					   { System.exit(0);
				     }
			       });

         ViewTransactionsPanel VT_Panel =  new ViewTransactionsPanel(StartDate,EndDate,CustomerID);
				       Container contentPane = getContentPane(); //add a panel to a frame
				       contentPane.add(VT_Panel);
	    			   show();
		}

 public static void main(String [] args)
		    { 		JFrame frame = new LoginBO(); //initialize a JFrame object
		   			//frame.add(tabbedPane);
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					//frame.setSize(550,350);
					frame.setVisible(true);

		   // JFrame frame = new CreateProfileBO();
		      frame.show(); //display the frame
    }
	}

