/******************************************************************************
*	Program Author: Dr. Zarna Patel and group Tang for CSCI 6810 Java and the Internet	  *
*	Date: February, 2014													  *
*******************************************************************************/

import java.lang.*; //including Java packages used by this program
import javax.swing.*;
import Dharti.Test.*;


public class LoginControl
{
    private Account Acct;
    TabbedMainBO mainTabBO;
   // private Socket socket;

    public LoginControl(String UName, String PWord) {
		Acct = new Account(UName, PWord);

		String CusInfo[] = Acct.signIn();
		String CustomerName = CusInfo[0];
        if (!CustomerName.equals("")) {
            //System.out.println("successful!");
            //JOptionPane.showMessageDialog(null, "Login is successful!", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
           // OpenBankAccountBO OpenAcctBO = new OpenBankAccountBO(UName, CustomerName);
           //PayTollManuallyBO PaytollBO = new PayTollManuallyBO(UName, CustomerName);
           //TabbedMainBO mainTabBO = new TabbedMainBO(UName,CustomerName);
        } else {
           // System.out.println("fail!");
            JOptionPane.showMessageDialog(null, "Login failed because of invalid username or password.", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
}



      try
      {
		String number = "SignIn"+";"+UName+";"+PWord;
		MailClient client = new MailClient();

		 CustomerName = client.SendReceiveMessage(number);

		if(!CustomerName.equals(""))
	 	  //JOptionPane.showMessageDialog(null, "Login is successful!", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
	 	  mainTabBO = new TabbedMainBO(UName,CustomerName);
	 	else
	 	  JOptionPane.showMessageDialog(null, "Login failed because of invalid username or password.", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
	 }
	 catch (Exception exception)
	 {
		 exception.printStackTrace();
     }
 }

}