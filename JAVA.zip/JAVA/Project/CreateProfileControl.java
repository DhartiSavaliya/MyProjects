/******************************************************************************
*	Program Author: Dr. Yongming Tang for CSCI 6810 Java and the Internet	  *
*	Date: February, 2014													  *
*******************************************************************************/

import java.lang.*; //including Java packages used by this program
import javax.swing.*;
import Com.Savaliya.*;
//import java.Project.*;

public class CreateProfileControl extends Customer
{
    private Account Acct;

   	 private Customer Cus;
   	 public String arg;


    public CreateProfileControl(String Name, String Street, String City, String State, String Zip, String Phone, String Email, String Balance)
    {


		   		Cus = new Customer(Name,Street,City,State,Zip,Phone,Email,Balance);
		   		String CustomerID = Cus.Createprofile();

		   		if(!CustomerID.equals(""))

		   		{
					// here call uuid method---------------------------
						//System.out.println("CUS_ID :" +CustomerID);
						JOptionPane.showMessageDialog(null, "Customer Profile Created Successfully.", "Confirmation", JOptionPane.INFORMATION_MESSAGE);



				}else {

					 JOptionPane.showMessageDialog(null, "Profile Creation Failed", "Confirmation", JOptionPane.INFORMATION_MESSAGE);

				}

		//boolean CustomerName = Acct.signIn();
		//String CustomerName = Acct.signIn();


	}
}

/*public class CreateProfileControl {

    public CreateProfileControl(String Name, String Street, String City, String State, String Zip, String Phone, String Email, String Balance, String UName) {
        float Bal = Float.parseFloat(String.valueOf(Balance)); //make balance float because balance is float value in db
        Customer cus = new Customer(Name, Street, City, State, Zip, Phone, Email, Bal, UName); //declare customer object with information
        if (cus.createProfile()) { //create the profile
            JOptionPane.showMessageDialog(null, "Create profile is successful!", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Create profile failed!", "Confirmation", JOptionPane.ERROR_MESSAGE);
        }
    }
}*/
