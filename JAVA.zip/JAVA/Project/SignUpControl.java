/******************************************************************************
*	Program Author: Dr. Yongming Tang for CSCI 6810 Java and the Internet	  *
*	Date: September, 2012													  *
*******************************************************************************/

import java.lang.*; //including Java packages used by this program

public class SignUpControl
{
    private SignUpBO SU_BO;

    public SignUpControl() {
		SU_BO = new SignUpBO();
	}
}