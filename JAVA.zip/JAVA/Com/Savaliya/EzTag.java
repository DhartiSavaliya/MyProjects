/******************************************************************************
*	Program Author: Dharti Savaliya for project on EzPass System	      *
*	Date: February, 2020						      *
*******************************************************************************/

package Com.Savaliya;

import java.lang.*; //including Java packages used by this program
import java.sql.*;
import java.time.LocalDate;
import Com.Savaliya.*;

public class EzTag
{
	private String TagCode, TagType, IssueDate, CustomerID;

	public EzTag(String V_tagcode, String Tagtype, String Issuedate, String Cust_ID){
	TagCode = V_tagcode;
	TagType = Tagtype;
	IssueDate = Issuedate;
	CustomerID = Cust_ID;
	}

	public EzTag(String V_tagcode){
		TagCode = V_tagcode;
		//TagType = getTagType(V_tagcode);
		//CustomerID = getCustomerID();
	}
	public EzTag(String V_tagcode, String Cus_ID){
			TagCode = V_tagcode;
			CustomerID = Cus_ID;
		}



	public boolean addTag(){
		boolean done = false;
					try{
						DBConnection ToDB = new DBConnection(); //Have a connection to the DB
						Connection DBConn = ToDB.openConn();
						Statement Stmt = DBConn.createStatement();
								System.out.println("ADD TAG");
								String SQL_Command = "INSERT INTO EzTag(TagCode, TagType, IssueDate, CustomerID) VALUES ('"+TagCode+"', '"+TagType+"', '"+IssueDate+"', '"+CustomerID+"')";
								//Stmt.executeUpdate(SQL_Command);
								int InsertRslt = Stmt.executeUpdate(SQL_Command);
																if (InsertRslt == 1){
																	done = true;
																//}
								//}
							}
						Stmt.close();
						ToDB.closeConn();
					}
					catch(java.sql.SQLException e)
								    {         done = false;
											 System.out.println("SQLException: " + e);
											 while (e != null)
											 {   System.out.println("SQLState: " + e.getSQLState());
												 System.out.println("Message: " + e.getMessage());
												 System.out.println("Vendor: " + e.getErrorCode());
												 e = e.getNextException();
												 System.out.println("");
											 }
								    }
								    catch (java.lang.Exception e)
								    {         done = false;
											 System.out.println("Exception: " + e);
											 e.printStackTrace ();
								    }
			    return done;
	}


	public boolean removeEzTag(){
		boolean done = false;
							try{
								DBConnection ToDB = new DBConnection(); //Have a connection to the DB
								Connection DBConn = ToDB.openConn();
								Statement Stmt = DBConn.createStatement();


								String SQL_Command = "SELECT * FROM EzTag WHERE CustomerID ='"+CustomerID+"'"; //SQL query command
								ResultSet Rslt = Stmt.executeQuery(SQL_Command); //Inquire if the username exsits.

								if(Rslt.next()) {

																		//System.out.println("LPN : " +LisensePlateNumber);
								String SQL_Command1 = "DELETE FROM EzTag WHERE TagCode = '"+TagCode+"'";
								int deleteRslt = Stmt.executeUpdate(SQL_Command1);
								 if(deleteRslt == 1){
								done = true;
								}
								Stmt.close();
									ToDB.closeConn();
								}

							}catch(java.sql.SQLException e)
										    {         done = false;
													 System.out.println("SQLException: " + e);
													 while (e != null)
													 {   System.out.println("SQLState: " + e.getSQLState());
														 System.out.println("Message: " + e.getMessage());
														 System.out.println("Vendor: " + e.getErrorCode());
														 e = e.getNextException();
														 System.out.println("");
													 }
										    }
										    catch (java.lang.Exception e)
										    {         done = false;
													 System.out.println("Exception: " + e);
													 e.printStackTrace ();
										    }
			    return done;








	}

}