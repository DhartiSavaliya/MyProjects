import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class MainBOPanel extends JPanel
{
private String CustomerID, UName, CName, StartDate, EndDate,CurrentBalance;
public MainBOPanel(String Username, String CustomerName, String Customer_ID)
{

			System.out.println("MainCustomerID"  +Customer_ID);

		this.CustomerID = Customer_ID;
		//System.out.println("MainBO CustomerID" +CustomerID);

		CName = CustomerName;
		UName = Username;
		//tabbedPane = new JTabbedPane();
		TabPanel1 = new CreateProfilePanel(UName, CName);
		TabPanel2 = new AddVehiclePanel(CustomerID);
		TabPanel3 =  new RemoveVehiclePanel(CustomerID);
		TabPanel4 = new EzTagPanel(CustomerID);
		TabPanel5 =  new RemoveEzTagPanel(CustomerID);
		TabPanel6 =  new AddTransactionsPanel(CustomerID);
		TabPanel7 =  new ViewTransactionsPanel(StartDate,EndDate,CustomerID);
		TabPanel8 =  new CreditCardPanel(CustomerID,CurrentBalance);






		JTabbedPane mp = new JTabbedPane();

		mp.add("Create Profile", TabPanel1);
		mp.add("Add Vehicle", TabPanel2);
		mp.add("Remove Vehicle", TabPanel3);
		mp.add("EZ Tag", TabPanel4);
		mp.add("Remove EzTag", TabPanel5);
		mp.add("Pay Toll", TabPanel6);
		mp.add("View Transaction", TabPanel7);
		mp.add("Recharge", TabPanel8);




		//System.out.println("THIS IS MAIN WINDOW");

//center the panel
        setLayout(new BorderLayout());
        add(mp, BorderLayout.CENTER);

}
   private JPanel   TabPanel1, TabPanel2, TabPanel3, TabPanel4,TabPanel5,TabPanel6,TabPanel7,TabPanel8;
   }

class MainBO extends JFrame
{
	private MainBOPanel MBO_Panel;
	private String CUS_ID;

  public MainBO(String Username, String CustomerName, String CustomerID)
  {

		//System.out.println("THIS IS MAIN BO");


	  CUS_ID = CustomerID;
     setTitle("EzPass System");
     setSize(770, 770);
     //get screen size and set the location of the frame
     Toolkit tk = Toolkit.getDefaultToolkit();
     Dimension d = tk.getScreenSize();
     int screenHeight = d.height;
     int screenWidth = d.width;
     setLocation( screenWidth / 2, screenHeight / 3);

     addWindowListener (new WindowAdapter()  //handle window closing event
        {  public void windowClosing (WindowEvent e)
           { System.exit(0);
           }
        });

        			       MBO_Panel =  new MainBOPanel(Username, CustomerName, CUS_ID);
					       Container contentPane = getContentPane(); //add a panel to a frame
					       contentPane.add(MBO_Panel);

		    				show();


 }

/*public static void main(String [] args)
   { JFrame frame = new MainBO(); //initialize a JFrame object
     frame.setVisible(true);
     frame.show(); //display the frame
   }*/
}