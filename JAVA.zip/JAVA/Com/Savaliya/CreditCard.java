/******************************************************************************
*	Program Author: Dharti Savaliya for project on EzPass System	      *
*	Date: February, 2020		       				      *
*******************************************************************************/

package Com.Savaliya;

import java.lang.*; //including Java packages used by this program
import java.sql.*;
import java.time.LocalDate;
import Com.Savaliya.*;

public class CreditCard
{
	private String CardNumber, Name, ExpirationDate, CVV, CurrentBalance, AddBalance, CustomerID;

	public CreditCard(String CardNO, String NM, String EXPDATE, String Cvv, String C_Bal, String A_Bal, String Cust_ID){
	CardNumber = CardNO;
	Name = NM;
	ExpirationDate = EXPDATE;
	CVV = Cvv;
	CurrentBalance = C_Bal;
	AddBalance = A_Bal;
	CustomerID = Cust_ID;
	}

	public CreditCard(String Cust_ID, String C_Bal){
		CustomerID = Cust_ID;
		CurrentBalance = C_Bal;
	}

	public CreditCard(){

	}

	public boolean addCreditCard(){
		boolean done = false;
		try{
				DBConnection ToDB = new DBConnection(); //Have a connection to the DB
				Connection DBConn = ToDB.openConn();
				Statement Stmt = DBConn.createStatement();
				String SQL_Command = "INSERT INTO CreditCard(CardNumber, Name, ExpirationDate, CVV, CurrentBalance, AddBalance, CustomerID) VALUES ('"+CardNumber+ "' , '" +Name+ "',  '" +ExpirationDate+ "', " +CVV+ ", '"+CurrentBalance+"', '"+AddBalance+"' ,'"+CustomerID+"')";
				int InsertRslt = Stmt.executeUpdate(SQL_Command);
				if (InsertRslt == 1){
						done = true;
				}
				Stmt.close();
			    ToDB.closeConn();
		}
	   catch(java.sql.SQLException e)
	   {         done = false;
	             System.out.println("SQLException: " + e);
				 while (e != null)
			               {   System.out.println("SQLState: " + e.getSQLState());
		              		   System.out.println("Message: " + e.getMessage());
							   System.out.println("Vendor: " + e.getErrorCode());
					           e = e.getNextException();
					           System.out.println("");
							}
		}
       catch (java.lang.Exception e)
		    {         done = false;
	        		  System.out.println("Exception: " + e);
					  e.printStackTrace ();
			}
    return done;

		}
	}

	//public boolean removeCreditCard(){

	//}

	//public boolean updateCreditCard(){

