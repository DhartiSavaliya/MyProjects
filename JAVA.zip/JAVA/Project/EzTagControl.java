import java.lang.*; //including Java packages used by this program
import javax.swing.*;
import java.awt.event.*;
import Com.Savaliya.*;
import Com.Savaliya.EzTag;




class EzTagControl
{
	public boolean addEzTag;
    public EzTagControl(String TagCode, String TagType, String IssueDate, String CustomerID)
	{
		// ADD EzTag
					EzTag Ez = new EzTag(TagCode, TagType, IssueDate, CustomerID);
					addEzTag = Ez.addTag();
					System.out.println("EzTagControl");
	}

}

