/******************************************************************************
*	Program Author: Dharti Savaliya for project on EzPass System	              *
*	Date: February, 2020													  *
*******************************************************************************/
import java.lang.*; //including Java packages used by this program
import javax.swing.*;
import java.awt.event.*;
import Com.Savaliya.*;
import java.util.*;
import java.sql.*;
//import project.*;


class ViewTransactionsControl
{
	public boolean ViewTransactions;

    public ViewTransactionsControl(String TransactionDate,String EndDate, String CustomerID)
	{
		Transaction T = new Transaction(TransactionDate,EndDate, CustomerID);
        Vector V = T.ViewTransactions(TransactionDate, EndDate, CustomerID);
	}

}