/******************************************************************************
*	Program Author: Zarna Patel for CSCI 6810 Java and the Internet	  *
*	Date: September, 2012													  *
*******************************************************************************/

package Dharti.Test;

import java.lang.*; //including Java packages used by this program
import java.sql.*;
import Dharti.Test.*;

public class Email
{
	public Email()
	{}
	public boolean signUp(String senderId,String receiverID,String emailSubject,String emailMessage )
	{
		boolean done = !senderId.equals("") && !receiverID.equals("") && !emailSubject.equals("") && !emailMessage.equals("");

		try{
			if(done)
			{
				DBConnection ToDB = new DBConnection(); //Have a connection to the DB
				Connection DBConn = ToDB.openConn();
		        Statement Stmt = DBConn.createStatement();
		        String SQL_Command = "INSERT INTO Email(Id,Subject,EmailBody,SentOn,SenderId,ReceiverId) VALUES"+
		        					 " (NEWID(),"+
		        					 "'"+emailSubject+"',"+
		        					 "'"+emailMessage+"',"+
		        					 "(Select CAST(GETDATE() AS smalldatetime)),"+
		        					 "'"+senderId+"',"+
		        					 "'"+receiverID+"')";
		        System.out.println(SQL_Command);
		        Stmt.executeUpdate(SQL_Command);
		        Stmt.close();
				ToDB.closeConn();
			}

		}
		catch(java.sql.SQLException e)
		{
			done = false;
			 System.out.println("SQLException: " + e);
			 while (e != null)
			 {   System.out.println("SQLState: " + e.getSQLState());
				 System.out.println("Message: " + e.getMessage());
				 System.out.println("Vendor: " + e.getErrorCode());
				 e = e.getNextException();
				 System.out.println("");
			 }
		}
		catch(Exception e)
		{
			done = false;
			System.out.println("Exception: " + e);
			e.printStackTrace ();
		}
		return done;

	}

    public String sentMails(String userID)
    {
		    String retMessage = "";
		    try{
				DBConnection ToDB = new DBConnection(); //Have a connection to the DB
				Connection DBConn = ToDB.openConn();
				Statement Stmt = DBConn.createStatement();
				String SQL_Command = "SELECT SenderId,ReceiverId,Subject,EmailBody,SentOn FROM Email WHERE SenderId='"+userID+"'";
				ResultSet Rslt = Stmt.executeQuery(SQL_Command);
				while(Rslt.next())
				{
					String sender = Rslt.getString("SenderId");
					String receiver = Rslt.getString("ReceiverId");
					String subject = Rslt.getString("Subject");
					String email = Rslt.getString("EmailBody");
					String date = Rslt.getDate("SentOn").toString()+" "+Rslt.getTime("SentOn").toString();

					retMessage = retMessage+receiver+";"+subject+";"+email+";"+date+"::";
				}
				Stmt.close();
				ToDB.closeConn();
			}
			catch (java.sql.SQLException e)
			{
			  System.out.println("SQLException: " + e);
			   while (e != null) {
				   System.out.println("SQLState: " + e.getSQLState());
				   System.out.println("Message: " + e.getMessage());
				   System.out.println("Vendor: " + e.getErrorCode());
				   e = e.getNextException();
				   System.out.println("");
			 	}
			 }
			 catch (java.lang.Exception e)
			 {
				  System.out.println("Exception: " + e);
				  e.printStackTrace();
			 }

			 return retMessage;

	}

	public String inboxMails(String userID)
	{
	    String retMessage = "";
	    try{
			DBConnection ToDB = new DBConnection(); //Have a connection to the DB
			Connection DBConn = ToDB.openConn();
			Statement Stmt = DBConn.createStatement();
			String SQL_Command = "SELECT SenderId,ReceiverId,Subject,EmailBody,SentOn FROM Email WHERE ReceiverId='"+userID+"'";
			ResultSet Rslt = Stmt.executeQuery(SQL_Command);
			while(Rslt.next())
			{
				String sender = Rslt.getString("SenderId");
				String receiver = Rslt.getString("ReceiverId");
				String subject = Rslt.getString("Subject");
				String email = Rslt.getString("EmailBody");
				String date = Rslt.getDate("SentOn").toString()+" "+Rslt.getTime("SentOn").toString();

				retMessage = retMessage+sender+";"+subject+";"+email+";"+date+"::";
			}
			Stmt.close();
			ToDB.closeConn();
		}
		catch (java.sql.SQLException e)
		{
		  System.out.println("SQLException: " + e);
		   while (e != null) {
			   System.out.println("SQLState: " + e.getSQLState());
			   System.out.println("Message: " + e.getMessage());
			   System.out.println("Vendor: " + e.getErrorCode());
			   e = e.getNextException();
			   System.out.println("");
		 	}
		 }
		 catch (java.lang.Exception e)
		 {
			  System.out.println("Exception: " + e);
			  e.printStackTrace();
		 }

		 return retMessage;

	}

	 /*public static void main(String [] args)
	 {
		 Email mail = new Email();
		 String emails = mail.inboxMails("apatel");
		 System.out.println(emails);

     }*/
}