/******************************************************************************
*	Program Author: Dharti Savaliya for project on EzPass Syste              *
*	Date: February, 2020     					      *
*******************************************************************************/
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.sql.*;
import Com.Savaliya.*;
import Com.Savaliya.Transaction;
import Com.Savaliya.Customer;

class AddTransactionsPanel extends JPanel implements ActionListener
{
    private JButton AddButton;
    private JTextField TransactionIDField, TagCodeField, TransactionDateField, TransactionTimeField, TollAmountField, TollPlazaField, TollLaneNumberField, CustomerIDField;
    private String TransactionID, TagCode, TransactionDate, TransactionTime, TollPlaza, CustomerID;
    private String TollAmount, TollLaneNumber;


    public AddTransactionsPanel()
    {}

    //public PayTollManuallyPanel(String EZTagCode, String TollAmount)
    public AddTransactionsPanel(String CustomerID)
    {

        AddButton = new JButton("Add"); //initializing two button references

        TransactionIDField = new JTextField(15);
        TagCodeField = new JTextField(15);
        TransactionDateField = new JTextField(15);
        TransactionTimeField = new JTextField(15);
        TollAmountField = new JTextField(15);
        TollPlazaField = new JTextField(15);
        TollLaneNumberField = new JTextField(15);
        CustomerIDField = new JTextField(15);
        CustomerIDField.setText(CustomerID);

        //JLabel TypeLabel = new JLabel("Choose Payment Type: ");
        JLabel TransactionIDLabel = new JLabel("Transaction ID:", SwingConstants.LEFT);
        JLabel TagCodeLabel = new JLabel("TagCode:", SwingConstants.LEFT);
        JLabel TransactionDateLabel = new JLabel("Transaction Date:", SwingConstants.LEFT);
        JLabel TransactionTimeLabel = new JLabel("Transaction Time:", SwingConstants.LEFT);
        JLabel TollAmountLabel = new JLabel("Toll Amount:", SwingConstants.LEFT);
        JLabel TollPlazaLabel = new JLabel("Toll Plaza:", SwingConstants.LEFT);
        JLabel TollLaneNumberLabel = new JLabel("Toll Lane Number:", SwingConstants.LEFT);
        JLabel CustomerIDLabel = new JLabel("CustomerID:", SwingConstants.LEFT);

        JPanel TypePanel = new JPanel();
        JPanel TransactionIDJPanel = new JPanel();
        JPanel TagCodeJPanel = new JPanel();
        JPanel TransactionDateJPanel = new JPanel();
        JPanel TransactionTimeJPanel = new JPanel();
        JPanel TollAmountJPanel = new JPanel();
        JPanel TollPlazaJPanel = new JPanel();
        JPanel TollLaneNumberJPanel = new JPanel();
		JPanel CustomerIDJPanel = new JPanel();

        TransactionIDJPanel.add(TransactionIDLabel);
        TransactionIDJPanel.add(TransactionIDField);
        TagCodeJPanel.add(TagCodeLabel);
        TagCodeJPanel.add(TagCodeField);
        TransactionDateJPanel.add(TransactionDateLabel);
        TransactionDateJPanel.add(TransactionDateField);
        TransactionTimeJPanel.add(TransactionTimeLabel);
        TransactionTimeJPanel.add(TransactionTimeField);
        TollAmountJPanel.add(TollAmountLabel);
        TollAmountJPanel.add(TollAmountField);
        TollPlazaJPanel.add(TollPlazaLabel);
        TollPlazaJPanel.add(TollPlazaField);
        TollLaneNumberJPanel.add(TollLaneNumberLabel);
        TollLaneNumberJPanel.add(TollLaneNumberField);
        CustomerIDJPanel.add(CustomerIDLabel);
        CustomerIDJPanel.add(CustomerIDField);

        AddButton.addActionListener(this);

        JPanel CenterPanel = new JPanel();
        CenterPanel.add(TransactionIDJPanel);
        CenterPanel.add(TagCodeJPanel);
        CenterPanel.add(TransactionDateJPanel);
        CenterPanel.add(TransactionTimeJPanel);
        CenterPanel.add(TollAmountJPanel);
        CenterPanel.add(TollPlazaJPanel);
        CenterPanel.add(TollLaneNumberJPanel);
        CenterPanel.add(CustomerIDJPanel);
		CenterPanel.add(AddButton);
		//CenterPanel.add(AddButton);


        // AddButton.addActionListener(this); //event listener registration
		        //JPanel TopPanel = new JPanel();
		       // TopPanel.add(TypePanel);
		        //TopPanel.add(TransactionIDJPanel);
		        //TopPanel.add(CenterPanel);


        //JPanel BottomPanel = new JPanel();
		//BottomPanel.add(AddButton);
		setLayout(new BorderLayout());
		add(CenterPanel, BorderLayout.CENTER);
		//add(BottomPanel, BorderLayout.CENTER);


        //add(PayButton, BorderLayout.SOUTH);//add the one button on to this panel
    }
    public void actionPerformed(ActionEvent evt)  //event handling
    {
        //Object source = evt.getSource(); //get who generates this event
        String arg = evt.getActionCommand();

        if (arg.equals("Add")) { //determine which button is clicked
            TransactionID = TransactionIDField.getText(); //take actions
            TagCode = TagCodeField.getText();
            TransactionDate = TransactionDateField.getText();
            TransactionTime = TransactionTimeField.getText();
            TollAmount = TollAmountField.getText();
            TollPlaza = TollPlazaField.getText();
            TollLaneNumber = TollLaneNumberField.getText();

            CustomerID = CustomerIDField.getText();

			 if (TransactionID.length() != 5 ) {
							JOptionPane.showMessageDialog(null, "Please Enter an Valid  Transaction ID with Exactly 5 Characters!", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
			            } else {
						Transaction T = new Transaction(TransactionID, TagCode, TransactionDate, TransactionTime, TollAmount, TollPlaza, TollLaneNumber, CustomerID);

						if(T.recordTransaction()){
							addTransactionsToPanel();
							JOptionPane.showMessageDialog(null, "Transaction Added Successfully!", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
							} else {
							JOptionPane.showMessageDialog(null, "Something went wrong!", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
							}
						}

					}
	}

	public void addTransactionsToPanel(){

		Transaction transactions = new Transaction(CustomerID);
		ResultSet rslt = null;
		//rslt = vehicle.viewVehicles();
		try {
			if((rslt != null)){

				//Loop through the list and add rows to Model
				int i =0;
				while(rslt.next())
				{
					 TransactionID = rslt.getString("TransactionID");
					 TagCode = rslt.getString("TagCode");
					 TransactionDate = rslt.getString("TransactionDate");
					 TransactionTime = rslt.getString("TransactionTime");
					 TollAmount = rslt.getString("TollAmount");
               		 TollPlaza = rslt.getString("TollPlaza");
		     		 TollLaneNumber = rslt.getString("TollLaneNumber");
                     CustomerID = rslt.getString("CustomerIDField");

					i++;
				}
			}
		} catch(SQLException e) {
			System.out.println("SQLException: " + e);
			while (e != null){
				System.out.println("SQLState: " + e.getSQLState());
				System.out.println("Message: " + e.getMessage());
				System.out.println("Vendor: " + e.getErrorCode());
				e = e.getNextException();
				System.out.println("");
			}

		} catch (Exception e) {
			System.out.println("Exception: " + e);
			e.printStackTrace ();
		}
}
	public class AddTransactionsBO extends JFrame
		    {

				public void AddTransactionsPanel(String CustomerID)
				{
					setTitle("Add Transaction");
					setSize(550, 350);

		         //get screen size and set the location of the frame
		         Toolkit tk = Toolkit.getDefaultToolkit();
		         Dimension d = tk.getScreenSize();
		         int screenHeight = d.height;
		         int screenWidth = d.width;
		         setLocation( screenWidth / 3, screenHeight / 4);

				   addWindowListener  (new WindowAdapter()
				   {
				   public void WindowClosing (WindowEvent e)
					   { System.exit(0);
				     }
			       });

				       AddTransactionsPanel AT_Panel =  new AddTransactionsPanel(CustomerID);
				       Container contentPane = getContentPane(); //add a panel to a frame
				       contentPane.add(AT_Panel);
	    			   show();
		}
}
 /*public static void main(String [] args)
		    { JFrame frame = new LoginBO(); //initialize a JFrame object
		   			//frame.add(tabbedPane);
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					//frame.setSize(550,350);
					frame.setVisible(true);

		   // JFrame frame = new CreateProfileBO();
		      frame.show(); //display the frame
    }*/
	}