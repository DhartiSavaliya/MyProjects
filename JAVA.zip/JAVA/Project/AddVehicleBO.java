
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.sql.*;
import Com.Savaliya.*;
import Com.Savaliya.Vehicle;
import Com.Savaliya.Customer;

class AddVehiclePanel extends JPanel implements ActionListener
{
    private JButton AddButton;
    private JTextField LicensePlateNumberField, MakeField, YearField, ModelField, ColorField, TagCodeField, CustomerIDField;
    private String LicensePlateNumber, Make, Year, Model, Color, TagCode;
    private String CustomerID;
    public AddVehiclePanel()
    {}

    //public PayTollManuallyPanel(String EZTagCode, String TollAmount)
    public AddVehiclePanel(String CustomerID)
    {
		/*Customer cust = newCustomer();
		cust.Createprofile = CustomerID;
        CustomerID = Acc.getCustomerID();*/

        AddButton = new JButton("Add"); //initializing two button references


        LicensePlateNumberField = new JTextField(15);
        //LicensePlateNumberField.setText(LicensedPlateNumber);
        MakeField = new JTextField(15);
       // TollAmountField.setText("0.00");
        YearField = new JTextField(15);
        ModelField = new JTextField(15);
        ColorField = new JTextField(15);
        TagCodeField = new JTextField(15);
        CustomerIDField = new JTextField(15);
        CustomerIDField.setText(CustomerID);



        //JLabel TypeLabel = new JLabel("Choose Payment Type: ");
        JLabel LicensePlateNumberLabel = new JLabel(" LicensePlateNumber:");
        JLabel MakeLabel = new JLabel("Make: ");
        JLabel YearLabel = new JLabel("Year:");
        JLabel ModelLabel = new JLabel("Model:");
        JLabel ColorLabel = new JLabel("Color:");
        JLabel TagCodeLabel = new JLabel("TagCode:");
        JLabel CustomerIDLabel = new JLabel("CustomerID:");


        JPanel TypePanel = new JPanel();
        JPanel LicensePlateNumberJPanel = new JPanel();
        JPanel MakeJPanel = new JPanel();
        JPanel YearJPanel = new JPanel();
        JPanel ModelJPanel = new JPanel();
        JPanel ColorJPanel = new JPanel();
        JPanel TagCodeJPanel = new JPanel();
		JPanel CustomerIDJPanel = new JPanel();
		/*VehicleIdNumberLabel.setFont(new Font("Arial", Font.BOLD, 14));
        VehicleIdNumberField.setFont(new Font("Arial", Font.BOLD, 14));
        MakeLabel.setFont(new Font("Arial", Font.BOLD, 14));
        MakeField.setFont(new Font("Arial", Font.BOLD, 14));
		YearLabel.setFont(new Font("Arial", Font.BOLD, 14));
        YearField.setFont(new Font("Arial", Font.BOLD, 14));
        ModelLabel.setFont(new Font("Arial", Font.BOLD, 14));
        ModelField.setFont(new Font("Arial", Font.BOLD, 14));
		AddButton.setFont(new Font("Arial", Font.BOLD, 14));*/
        LicensePlateNumberJPanel.add(LicensePlateNumberLabel);
        LicensePlateNumberJPanel.add(LicensePlateNumberField);
        MakeJPanel.add(MakeLabel);
        MakeJPanel.add(MakeField);
        YearJPanel.add(YearLabel);
        YearJPanel.add(YearField);
        ModelJPanel.add(ModelLabel);
        ModelJPanel.add(ModelField);
        ColorJPanel.add(ColorLabel);
        ColorJPanel.add(ColorField);
        TagCodeJPanel.add(TagCodeLabel);
        TagCodeJPanel.add(TagCodeField);
        CustomerIDJPanel.add(CustomerIDLabel);
        CustomerIDJPanel.add(CustomerIDField);

        AddButton.addActionListener(this);
        //event listener registration
        JPanel TopPanel = new JPanel();
        TopPanel.add(TypePanel);
        TopPanel.add(LicensePlateNumberJPanel);

        JPanel CenterPanel = new JPanel();
        CenterPanel.add(LicensePlateNumberJPanel);
        CenterPanel.add(MakeJPanel);
        CenterPanel.add(YearJPanel);
        CenterPanel.add(ModelJPanel);
        CenterPanel.add(ColorJPanel);
        CenterPanel.add(TagCodeJPanel);
        CenterPanel.add(CustomerIDJPanel);

        CenterPanel.add(AddButton);

        setLayout(new BorderLayout());
        add(TopPanel, BorderLayout.NORTH);
        add(CenterPanel, BorderLayout.CENTER);
        //add(PayButton, BorderLayout.SOUTH);//add the one button on to this panel
    }
    public void actionPerformed(ActionEvent evt)  //event handling
    {
        //Object source = evt.getSource(); //get who generates this event
        String arg = evt.getActionCommand();

        if (arg.equals("Add")) { //determine which button is clicked
            LicensePlateNumber = LicensePlateNumberField.getText(); //take actions
            Make = MakeField.getText();
            Year = YearField.getText();
            Model = ModelField.getText();
            Color = ColorField.getText();
            TagCode = TagCodeField.getText();
            CustomerID = CustomerIDField.getText();

            if (LicensePlateNumber.length() != 5 ) {
				JOptionPane.showMessageDialog(null, "Please Enter an Valid  LincesePlateNumber with Exactly 10 Characters!", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
            } else {
			Vehicle V = new Vehicle(LicensePlateNumber, Make, Model, Year, Color, TagCode, CustomerID);

			if(V.addVehicle()){
				addVehicleToPanel();
				JOptionPane.showMessageDialog(null, "Vehicle Added Successfully!", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
				} else {
				JOptionPane.showMessageDialog(null, "Something went wrong!", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
				}
			}

		}

	}
	public void addVehicleToPanel(){

		Vehicle vehicle = new Vehicle(CustomerID);
		ResultSet rsTxns = null;
		//rsTxns = vehicle.viewVehicles();
		try {
			if((rsTxns != null)){

				//Loop through the list and add rows to Model
				int i =0;
				while(rsTxns.next())
				{
					LicensePlateNumber = rsTxns.getString("VIN");
					Make = rsTxns.getString("Make");
					Year = rsTxns.getString("Year");
					Model = rsTxns.getString("Model");
					Color = rsTxns.getString("Color");
					TagCode = rsTxns.getString("TagCode");


					i++;
				}
			}
		} catch(SQLException e) {
			System.out.println("SQLException: " + e);
			while (e != null){
				System.out.println("SQLState: " + e.getSQLState());
				System.out.println("Message: " + e.getMessage());
				System.out.println("Vendor: " + e.getErrorCode());
				e = e.getNextException();
				System.out.println("");
			}

		} catch (Exception e) {
			System.out.println("Exception: " + e);
			e.printStackTrace ();
		}
}
	public class AddVehicleBO extends JFrame
		    {
				private AddVehiclePanel AV_Panel;
				private String CustomerID;
				public void AddVehiclePanel(String CustomerID)
				{
					setTitle("Vehicle");
					setSize(550, 350);

		         //get screen size and set the location of the frame
		         Toolkit tk = Toolkit.getDefaultToolkit();
		         Dimension d = tk.getScreenSize();
		         int screenHeight = d.height;
		         int screenWidth = d.width;
		         setLocation( screenWidth / 3, screenHeight / 4);

				   addWindowListener  (new WindowAdapter()
				   {
				   public void WindowClosing (WindowEvent e)
					   { System.exit(0);
				     }
			       });

				       AV_Panel =  new AddVehiclePanel(CustomerID);
				       Container contentPane = getContentPane(); //add a panel to a frame
				       contentPane.add(AV_Panel);
	    				show();
		}
}
 public static void main(String [] args)
		    { JFrame frame = new LoginBO(); //initialize a JFrame object
		   			//frame.add(tabbedPane);
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					//frame.setSize(550,350);
					frame.setVisible(true);

		   // JFrame frame = new CreateProfileBO();
		      frame.show(); //display the frame
    }
	}