import java.lang.*; //including Java packages used by this program
import javax.swing.*;
import java.awt.event.*;
import Com.Savaliya.*;
import Com.Savaliya.EzTag;




class RemoveEzTagControl
{
	public boolean removeEzTag;
    public RemoveEzTagControl(String TagCode,String CustomerID)
	{
		// ADD EzTag
					EzTag Ez = new EzTag(TagCode,CustomerID);
					removeEzTag = Ez.addTag();
					System.out.println("EzTagControl");
	}

}

