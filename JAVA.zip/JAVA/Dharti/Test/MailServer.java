
package Dharti.Test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import Dharti.Test.*;
import Dharti.Test.*;




public class MailServer
{

    private static Socket socket;

    public static void main(String[] args)
    {
        try
        {

            int port = 1433;
            ServerSocket serverSocket = new ServerSocket(port);
            System.out.println("Server Started and listening to the port 25000");

            //Server is running always. This is done using this while(true) loop
            while(true)
            {
                //Reading the message from the client
                socket = serverSocket.accept();
                InputStream is = socket.getInputStream();
                InputStreamReader isr = new InputStreamReader(is);
                BufferedReader br = new BufferedReader(isr);
                String clientsentMessage = br.readLine();
                System.out.println("Message received from client is "+clientsentMessage);


                //Multiplying the number by 2 and forming the return message
                String returnMessage ="";
                try
                {
					if(clientsentMessage.startsWith("SignIn"))
					{
						returnMessage = login(clientsentMessage);
						if (returnMessage.equals(""))
							returnMessage = "InValid";
					}
					else if(clientsentMessage.startsWith("SignUp"))
					{
						if(signup(clientsentMessage))
							returnMessage = "Valid";
						else
							returnMessage = "InValid";
					}
					else if(clientsentMessage.startsWith("Send"))
					{
						if(sent(clientsentMessage))
							returnMessage = "Valid";
						else
							returnMessage = "InValid";
					}
					else if(clientsentMessage.startsWith("Inbox"))
					{
						returnMessage = inbox(clientsentMessage);
					}
					else if(clientsentMessage.startsWith("OutBox"))
					{
						returnMessage = outbox(clientsentMessage);
					}

                }
                catch(NumberFormatException e)
                {
                    //Input was not a number. Sending proper message back to client.
                    returnMessage = "Please send a proper number";
                }

				returnMessage = returnMessage + "\n";
                //Sending the response back to the client.
                OutputStream os = socket.getOutputStream();
                OutputStreamWriter osw = new OutputStreamWriter(os);
                BufferedWriter bw = new BufferedWriter(osw);
                bw.write(returnMessage);
                System.out.println("Message sent to the client is "+returnMessage);
                bw.flush();
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                socket.close();
            }
            catch(Exception e){}
        }
    }

    static boolean signup(String signText)
    {
		try{
			String messages[] = signText.split(";");

			String UName = messages[1];
			String PWord = messages[2]; //take actions
			String PsWord1 = messages[3];
			String Name = messages[4];

			Account Acct = new Account(UName, PWord, PsWord1, Name);
            if (Acct.signUp())
			  return true;
			else
			  return false;
		}
		catch(Exception e)
		{
		  return false;
		}
	}
    static String login(String loginText)
    {
		try{
			String messages[] = loginText.split(";");
			String UName = messages[1];
			String PWord = messages[2];
			System.out.println(UName);
			System.out.println(PWord);
			Account Acct = new Account(UName, PWord);
			String CusInfo[] = Acct.signIn();
			String CustomerName = CusInfo[0];
			return CustomerName;
		}
		catch(Exception e)
		{
			return "";
		}
	}

	static boolean sent(String emailText)
	{
	   try{
		   String message[] = emailText.split(";");
		   String sender = message[1];
		   String receiver = message[2];
		   String subject = message[3];
		   String messageText = message[4];

		   Email email = new Email();
		   if(email.signUp(sender,receiver,subject,messageText))
		   	return true;
		   else
		   	return false;

	   }
	   catch(Exception e)
	   {
		   return false;
	   }
	}

	static String inbox(String userId)
	{
		try{
			String messages[] = userId.split(";");

			String UName = messages[1];

			Email mail = new Email();
			return mail.inboxMails(UName);
		}
		catch(Exception e)
		{
			return "InValid";
		}
	}

	static String outbox(String userId)
	{
		try{
		     String messages[] = userId.split(";");

			 String UName = messages[1];

			 Email mail = new Email();
			 return mail.sentMails(UName);

		}
		catch(Exception e)
		{
			return "Invalid";
		}
	}
}