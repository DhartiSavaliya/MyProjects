import Com.Savaliya.Vehicle;

/*class RemoveVehicleControl
{
  public boolean removeVehicle;

  public RemoveVehicleControl(String paramString)
  {
    Vehicle localVehicle = new Vehicle(paramString);
    this.removeVehicle = localVehicle.removeVehicle();
  }*/
class RemoveVehicleControl
{
	public boolean removeVehicle;
    public RemoveVehicleControl(String CustomerID,String LicensePlateNumber)
	{
		// RemoveVEHICLE
		Vehicle V = new Vehicle(CustomerID,LicensePlateNumber);
        removeVehicle = V.removeVehicle();
        System.out.println("RVControl" +removeVehicle);
	}
}

		/*EzAccount CustomerEzAccount = new EzAccount(Account_Num);
		float DeductionAmt = new Float(TollAmount).floatValue();

		deductionResult = CustomerEzAccount.deductTollAmount(DeductionAmt);

		// Record Transaction
		Transactio TransactionRec = new Transactio(EZTagCode, Account_Num, TransactionDate,TransactionTime,TollAmount,TollPlazaId);
		IsTransactionRecorded = TransactionRec.sRecordTransaction();*/


