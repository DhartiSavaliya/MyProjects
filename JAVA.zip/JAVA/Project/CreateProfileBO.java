/******************************************************************************
*	Program Author: Dharti Savaliya for CSCI 6810 Java and the Internet	      *
*	Date: February, 2020													 *
*******************************************************************************/

import java.awt.*;     //including Java packages used by this program
import java.awt.event.*;
import javax.swing.*;
import java.time.LocalDate;



 class CreateProfilePanel extends JPanel implements ActionListener // Implementing ActionListener is for event handling.
{
    private JButton SubmitButton, CancelButton;  //Instance variables
    private JTextField NameField, StreetField, CityField, StateField, ZipField, PhoneField, EmailField, BalanceField, CustomerIDField;
    private JComboBox CreateProfileBox,CreateProfileBox1 ;
    private String Name, Street, Zip, Phone, Email, Balance, StateBox, Citybox;
    			//private String Uname;

   // private JMenu MyAccountMenu;
//	private JMenuBar MyAccountMenuBar;
	//private JMenuItem UpdatecustomerprofileMenuItem, changepasswordMenuItem, logoutMenuItem;


	public CreateProfilePanel(String Uname,String Cname)
	{


		   // String CusID = Integer.toString(Cus_ID);

		/*JTabbedPane tabbedPane = new JTabbedPane();
		JPanel panel1,panel2,panel3,panel4,panel5,panel6;
		panel1 = new JPanel();
		panel2 = new JPanel();
		panel3 = new JPanel();
	    panel4 = new JPanel();
	    panel5 = new JPanel();
		panel6 = new JPanel();

		tabbedPane.addTab("Create Profile", panel1);
		tabbedPane.addTab("Pay Toll", panel2);
	    tabbedPane.addTab("EZ Tag", panel3);
		tabbedPane.addTab("Vehicle", panel4);
		tabbedPane.addTab("Inquire Transactions", panel5);
		tabbedPane.addTab("MyAccount", panel6);*/

		SubmitButton = new JButton("Submit");
		CancelButton = new JButton("cancel"); // initializing two button references

		NameField = new JTextField(15);
		NameField.setText(Cname);
		StreetField = new JTextField(15);
		//CustomerIDField = new JTextField(15);
		//CustomerIDField.setText(CusID);
		//StateField = new JTextField(15);
		ZipField = new JTextField(15);
		PhoneField = new JTextField(15);
		EmailField = new JTextField(15);
		BalanceField = new JTextField(15);
		BalanceField.setText("0.0");

		CreateProfileBox = new JComboBox();
		//CreateProfileBox.setText("Select City");

		CreateProfileBox.addItem("Select City");
		CreateProfileBox.addItem("Teanack");
		CreateProfileBox.addItem("Hakensack");
		CreateProfileBox.addItem("Edison");
		CreateProfileBox.addItem("New York");
		CreateProfileBox.addItem("Hasbruck Heights");
		CreateProfileBox.addItem("Jersey City");
		CreateProfileBox.addItem("Avenel");

		CreateProfileBox1 = new JComboBox();
		//CreateProfileBox.setText("Select State");
		CreateProfileBox1.addItem("Select State");
		CreateProfileBox1.addItem("New Jersey");
		CreateProfileBox1.addItem("New York");
		CreateProfileBox1.addItem("Texas");
		CreateProfileBox1.addItem("Washington");
		CreateProfileBox1.addItem("Indiana");
		CreateProfileBox1.addItem("Callifornia");
		CreateProfileBox1.addItem("Ohio");

		JLabel NameLabel = new JLabel("Name:");
		JLabel StreetLabel = new JLabel("Street:");
		//JLabel CustomerIDLabel = new JLabel("Customer ID:");
		//JLabel StateLabel = new JLabel("Select State:");
		JLabel ZipLabel = new JLabel("Zip:");
		JLabel PhoneLabel = new JLabel("Phone:");
		JLabel EmailLabel = new JLabel("Email:");
		JLabel BalanceLabel = new JLabel("Balance:");

		SubmitButton.addActionListener(this);  //event listener registration
		CancelButton.addActionListener(this);


		JPanel NamePanel =  new JPanel();
		JPanel StreetPanel =  new JPanel();
		//JPanel CusPanel =  new JPanel();
		//JPanel StatePanel =  new JPanel();
		JPanel ZipPanel =  new JPanel();
		JPanel PhonePanel =  new JPanel();
		JPanel EmailPanel =  new JPanel();
		JPanel BalancePanel =  new JPanel();
		JPanel TypePanel =  new JPanel();
		JPanel Statepanel =  new JPanel();


		NamePanel.add(NameLabel);
		NamePanel.add(NameField);
		StreetPanel.add(StreetLabel);
		StreetPanel.add(StreetField);
		//CusPanel.add(CustomerIDLabel);
		//CusPanel.add(CustomerIDField);
		TypePanel.add(CreateProfileBox);
		Statepanel.add(CreateProfileBox1);
		//TypePanel.add(CreateProfileBox1);
		//CityPanel.add(CreateProfileBox);
		//StatePanel.add(StateLabel);
		//StatePanel.add(StateField);
		ZipPanel.add(ZipLabel);
		ZipPanel.add(ZipField);
		PhonePanel.add(PhoneLabel);
		PhonePanel.add(PhoneField);
		EmailPanel.add(EmailLabel);
		EmailPanel.add(EmailField);
		BalancePanel.add(BalanceLabel);
		BalancePanel.add(BalanceField);

		JPanel CenterPanel = new JPanel();
		//CenterPanel.add(tabbedPane);
		CenterPanel.add(NamePanel);
		//CenterPanel.add(CusPanel);
		CenterPanel.add(StreetPanel);
		CenterPanel.add(TypePanel);
		CenterPanel.add(Statepanel);
		CenterPanel.add(ZipPanel);
		CenterPanel.add(PhonePanel);
		CenterPanel.add(EmailPanel);
		CenterPanel.add(BalancePanel);
		CenterPanel.add(SubmitButton);
		CenterPanel.add(CancelButton);

		//MyAccountMenuBar = new JMenuBar();
			         //MyAccountMenu = new JMenu("MyAccount"); // initializing menus
			         //MyAccountMenu.setMnemonic('M');

			         //UpdatecustomerprofileMenuItem = new JMenuItem("Update Customer Profile", 'U');
			        // changepasswordMenuItem = new JMenuItem("change password", 'C');
			        // logoutMenuItem = new JMenuItem("Logout", 'L');

			        /* MyAccountMenu.add(UpdatecustomerprofileMenuItem);
			         MyAccountMenu.addSeparator();
			         MyAccountMenu.add(changepasswordMenuItem);
					 MyAccountMenu.addSeparator();
			         MyAccountMenu.add(logoutMenuItem);
					 MyAccountMenu.addSeparator();

					 setJMenuBar(MyAccountMenuBar);*/




		//JPanel CreateProfilePanel = new JPanel();
		//CreateProfilePanel.add(SubmitButton);
		//CreateProfilePanel.add(CancelButton);



		//Container contentPane = getContentPane(); //add a panel to a frame
		//contentPane.add(LoginPanel);



		setLayout(new BorderLayout());
		add(CenterPanel, BorderLayout.CENTER);




	}


    public void actionPerformed(ActionEvent evt)  //event handling
    {
         String arg = evt.getActionCommand();


		if (arg.equals("Submit")) {
			//System.out.println("Name: "+arg);
			String Name = NameField.getText();
			String Street = StreetField.getText();
		    String StateBox = (String)CreateProfileBox.getSelectedItem();
		    String CityBox = (String)CreateProfileBox1.getSelectedItem();
		    String Zip = ZipField.getText();
			String Phone = PhoneField.getText();
			String Email = EmailField.getText();
			String Balance = BalanceField.getText();

/*System.out.println(Name);//
System.out.println(Street);//
System.out.println(StateBox);//
System.out.println(CityBox);//
System.out.println(Zip);//
System.out.println(Phone);//
System.out.println(Email);//
System.out.println(Balance);*/

	 CreateProfileControl CrePro_Ctrl = new CreateProfileControl(Name, Street, StateBox, CityBox, Zip,Phone,Email,Balance);



        }else {


				System.out.println("Cancel");

			}
    }

}

     public class CreateProfileBO extends JFrame
	    {
			private CreateProfilePanel CP_Panel;
			private JMenu MyAccountMenu;
			private JMenuBar MyAccountMenuBar;
			private JMenuItem UpdatecustomerprofileMenuItem, changepasswordMenuItem, logoutMenuItem;
			private String Uname;

			//public CreateProfileBO(String Name){
				//Uname = Name;
				//}

			public CreateProfileBO(String Name,String CustomerName, String CustomerID)
			{
				setTitle("Create Pofile");
				setSize(500, 350);

				 Uname = Name;
				 String Cname = CustomerName;
				String CUS_ID = CustomerID;

			System.out.println("Uname: "+Uname);
			System.out.println("Cname: "+Cname);
			System.out.println("CusID: "+CUS_ID);


			//int Cus_ID = (100000 + new Random().nextInt(800000));
		  //  System.out.println("CustomerID is :" +Cus_ID);


	         //get screen size and set the location of the frame
	         Toolkit tk = Toolkit.getDefaultToolkit();
	         Dimension d = tk.getScreenSize();
	         int screenHeight = d.height;
	         int screenWidth = d.width;
	         setLocation( screenWidth / 3, screenHeight / 4);

	          addWindowListener (new WindowAdapter() //handle window event
			 	            {
			 			       public void windowClosing (WindowEvent e)
			 				                  { System.exit(0);
			 	               }
			 	            });






			   MyAccountMenuBar = new JMenuBar();
			   MyAccountMenu = new JMenu("My Account"); // initializing menus
			   MyAccountMenu.setMnemonic('M');
			   UpdatecustomerprofileMenuItem = new JMenuItem("Update Customer Profile", 'U');
			   changepasswordMenuItem = new JMenuItem("change password", 'C');
	           logoutMenuItem = new JMenuItem("Logout", 'L');

	                     MyAccountMenu.add(UpdatecustomerprofileMenuItem);
			   	         MyAccountMenu.addSeparator();
			   	         MyAccountMenu.add(changepasswordMenuItem);
			   			 MyAccountMenu.addSeparator();
			   	         MyAccountMenu.add(logoutMenuItem);
			   			 MyAccountMenu.addSeparator();

			   			 setJMenuBar(MyAccountMenuBar);



			       CP_Panel =  new CreateProfilePanel(Uname,Cname);
			       Container contentPane = getContentPane(); //add a panel to a frame
			       contentPane.add(CP_Panel);

    				show();



	}

	   public static void main(String [] args)
	    { //JFrame frame = new LoginBO(); //initialize a JFrame object
	    	JFrame frame = new TabFrame();
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setVisible(true);

	      frame.show(); //display the frame
    }
}
