
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.table.AbstractTableModel;
import java.util.*;
import java.util.List;
import java.sql.*;

import Com.Savaliya.*;
import Com.Savaliya.Vehicle;

class AddVehiclePanel extends JPanel implements ActionListener
{
    private JButton AddButton;
    private JTextField LicensePlateNumberField, MakeField, YearField, ModelField, ColorField, TagCodeField, CustomerIDField;
    private String LicensePlateNumber, Make, Year, Model, Color, TagCode;
    private String CustomerID;
    private DefaultTableModel TxnTableModel;
   // private AddVehicleControl AD_Ctrl;
    public AddVehiclePanel()
    {}

    //public PayTollManuallyPanel(String EZTagCode, String TollAmount)
    public AddVehiclePanel(String CustomerID)
    {
		//Account Acc = new Account();
		//Acc.signIn = CustomerID;
        //Account_Num = EzAcc.getEzAccountNum();

        AddButton = new JButton("Add"); //initializing two button references


        LicensePlateNumberField = new JTextField(15);
        //LicensePlateNumberField.setText(LicensedPlateNumber);
        MakeField = new JTextField(15);
       // TollAmountField.setText("0.00");
        YearField = new JTextField(15);
        ModelField = new JTextField(15);
        ColorField = new JTextField(15);
        TagCodeField = new JTextField(15);
        CustomerIDField = new JTextField(15);



        //JLabel TypeLabel = new JLabel("Choose Payment Type: ");
        JLabel LicensePlateNumberLabel = new JLabel(" LicensePlateNumber:");
        JLabel MakeLabel = new JLabel("Make: ");
        JLabel YearLabel = new JLabel("Year:");
        JLabel ModelLabel = new JLabel("Model:");
        JLabel ColorLabel = new JLabel("Color:");
        JLabel TagCodeLabel = new JLabel("TagCode:");
        JLabel CustomerIDLabel = new JLabel("CustomerID:");


        JPanel TypePanel = new JPanel();
        JPanel LicensePlateNumberJPanel = new JPanel();
        JPanel MakeJPanel = new JPanel();
        JPanel YearJPanel = new JPanel();
        JPanel ModelJPanel = new JPanel();
        JPanel ColorJPanel = new JPanel();
        JPanel TagCodeJPanel = new JPanel();
		JPanel CustomerIDJPanel = new JPanel();

		/*VehicleIdNumberLabel.setFont(new Font("Arial", Font.BOLD, 14));
        VehicleIdNumberField.setFont(new Font("Arial", Font.BOLD, 14));
        MakeLabel.setFont(new Font("Arial", Font.BOLD, 14));
        MakeField.setFont(new Font("Arial", Font.BOLD, 14));
		YearLabel.setFont(new Font("Arial", Font.BOLD, 14));
        YearField.setFont(new Font("Arial", Font.BOLD, 14));
        ModelLabel.setFont(new Font("Arial", Font.BOLD, 14));
        ModelField.setFont(new Font("Arial", Font.BOLD, 14));
		AddButton.setFont(new Font("Arial", Font.BOLD, 14));*/

        LicensePlateNumberJPanel.add(LicensePlateNumberLabel);
        LicensePlateNumberJPanel.add(LicensePlateNumberField);
        MakeJPanel.add(MakeLabel);
        MakeJPanel.add(MakeField);
        YearJPanel.add(YearLabel);
        YearJPanel.add(YearField);
        ModelJPanel.add(ModelLabel);
        ModelJPanel.add(ModelField);
        ColorJPanel.add(ColorLabel);
        ColorJPanel.add(ColorField);
        TagCodeJPanel.add(TagCodeLabel);
        TagCodeJPanel.add(TagCodeField);
        CustomerIDJPanel.add(CustomerIDLabel);
        CustomerIDJPanel.add(CustomerIDField);

        AddButton.addActionListener(this);
        //event listener registration

        JPanel TopPanel = new JPanel();
        TopPanel.add(TypePanel);
        TopPanel.add(LicensePlateNumberJPanel);

        JPanel CenterPanel = new JPanel();
        CenterPanel.add(LicensePlateNumberJPanel);
        CenterPanel.add(MakeJPanel);
        CenterPanel.add(YearJPanel);
        CenterPanel.add(ModelJPanel);
        CenterPanel.add(ColorJPanel);
        CenterPanel.add(TagCodeJPanel);
        CenterPanel.add(CustomerIDJPanel);


        CenterPanel.add(AddButton);


 		// Data to be displayed in the JTable
		String[][] data = {{"", "", "", "", "", "", "", "", ""}};


		// Column Names
		String[] columnNames = {"LicensePlateNumber", "Make", "Year", "Model", "Color", "TagCode", "Remove"};


		//TableModel tm = new TableModel();
		TxnTableModel = new DefaultTableModel();
		TxnTableModel.setColumnIdentifiers(columnNames);
		//DefaultTableModel model = new DefaultTableModel(tm.getData1(), tm.getColumnNames());

		// Initializing the JTable
		JTable TxnTable = new JTable();
		TxnTable.setModel(TxnTableModel);

		TableCellRenderer defaultRenderer = TxnTable.getDefaultRenderer(JButton.class);
    	TxnTable.setDefaultRenderer(JButton.class, new JTableButtonRenderer(defaultRenderer));
		//TableCellRenderer buttonRenderer = new JTableButtonRenderer();
    	TxnTable.getColumn("Remove").setCellRenderer(new JTableButtonRenderer(defaultRenderer));
    	TxnTable.addMouseListener(new JTableButtonMouseListener(TxnTable, TxnTableModel, CustomerID));
		TxnTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		TxnTable.setFillsViewportHeight(true);
		TxnTable.setRowHeight(20);
		TxnTable.setFont(new Font("Arial", Font.PLAIN, 14));
		addVehicleToPanel();
		//TxnTable.setBounds(40, 50, 300, 400);

		// adding it to JScrollPane
		JScrollPane sp = new JScrollPane(TxnTable);
		sp.setPreferredSize(new Dimension(800, 300));
		sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

		CenterPanel.add(sp);

        setLayout(new BorderLayout());
        add(TopPanel, BorderLayout.NORTH);
        add(CenterPanel, BorderLayout.CENTER);
        //add(PayButton, BorderLayout.SOUTH);//add the one button on to this panel
    }



    public void actionPerformed(ActionEvent evt)  //event handling
    {
        //Object source = evt.getSource(); //get who generates this event
        String arg = evt.getActionCommand();

        if (arg.equals("Add")) { //determine which button is clicked
            LicensePlateNumber = LicensePlateNumberField.getText(); //take actions
            Make = MakeField.getText();
            Year = YearField.getText();
            Model = ModelField.getText();
            Color = ColorField.getText();
            TagCode = TagCodeField.getText();

            if (LicensePlateNumber.length() != 10 ) {
				JOptionPane.showMessageDialog(null, "Please Enter an Valid  VehicleIdNumber with Exactly 10 Characters!", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
            } else {
			Vehicle V = new Vehicle(LicensePlateNumber, Make,Model,  Year, Color, TagCode, CustomerID);

			if(V.addVehicle()){
				addVehicleToPanel();
				JOptionPane.showMessageDialog(null, "Vehicle Added Successfully!", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
				} else {
				JOptionPane.showMessageDialog(null, "Something went wrong!", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
				}
			}

		}

	}




	public void addVehicleToPanel(){
		TxnTableModel.setRowCount(0);

		Vehicle vehicle = new Vehicle(CustomerID);
		ResultSet rsTxns = null;
		//rsTxns = vehicle.viewVehicles();
		try {
			if((rsTxns != null)){

				//Loop through the list and add rows to Model
				int i =0;
				while(rsTxns.next())
				{
					LicensePlateNumber = rsTxns.getString("VIN");
					Make = rsTxns.getString("Make");
					Year = rsTxns.getString("Year");
					Model = rsTxns.getString("Model");
					Color = rsTxns.getString("Color");
					TagCode = rsTxns.getString("TagCode");

					TxnTableModel.addRow(new Object[]{LicensePlateNumber, Make, Model,  Year, Color, TagCode, "Remove"});
					i++;
				}
			}
		} catch(SQLException e) {
			System.out.println("SQLException: " + e);
			while (e != null){
				System.out.println("SQLState: " + e.getSQLState());
				System.out.println("Message: " + e.getMessage());
				System.out.println("Vendor: " + e.getErrorCode());
				e = e.getNextException();
				System.out.println("");
			}

		} catch (Exception e) {
			System.out.println("Exception: " + e);
			e.printStackTrace ();
		}

}

}







class JTableButtonRenderer extends JButton implements TableCellRenderer {

	  private TableCellRenderer __defaultRenderer;

	  public JTableButtonRenderer(TableCellRenderer renderer) {
	    __defaultRenderer = renderer;
  	}

	@Override public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
			//JButton button = (JButton)value;
			JButton button = new JButton("Remove");
			if (isSelected) {
				button.setForeground(table.getSelectionForeground());
				button.setBackground(table.getSelectionBackground());
		    } else {
		    	button.setForeground(table.getForeground());
		    	button.setBackground(UIManager.getColor("Button.background"));
		    }
			return button;
		}

	/* @Override
	public Component getTableCellRendererComponent(JTable table, Object obj,boolean selected, boolean focused, int row, int col) {
	//SET PASSED OBJECT AS BUTTON TEXT
	//setText((obj==null) ? "":obj.toString());
	setText((obj==null) ? "":"Remove");
	return this;
	}*/



}



class JTableButtonMouseListener extends MouseAdapter {
	private final JTable table;
	private final String CustomerID;
	private DefaultTableModel TxnTableModel;
	private String LicensePlateNumber, Make, Model, Year, Color, TagCode;
	private static final String[] COLUMN_NAMES = new String[] {"LicensePlateNumber", "Make", "Model", "Year", "Color", "TagCode", "Remove"};

	public JTableButtonMouseListener(JTable table, DefaultTableModel TxnTblModel, String Cust_ID) {
		this.table = table;
		this.TxnTableModel = TxnTblModel;
		this.CustomerID = Cust_ID;
	}

	public void mouseClicked(MouseEvent e) {
		int column = table.getColumnModel().getColumnIndexAtX(e.getX());
		int row    = e.getY()/table.getRowHeight();

		if (row < table.getRowCount() && row >= 0 && column < table.getColumnCount() && column >= 0) {
			Object objVIN = this.table.getModel().getValueAt(row, 0);

			if (column == 4) {

				/* final JButton button = new JButton(COLUMN_NAMES[column]);
					button.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent arg0) { */
							// Remove Vehicle Code and refresh the Grid
				Vehicle vehicle = new Vehicle(CustomerID);
				//vehicle.LicensePlateNumber = objVIN.toString();
				boolean delResult = vehicle.removeVehicle();
				TxnTableModel.setRowCount(0);
				ResultSet rsTxns = null;
				//rsTxns = vehicle.viewVehicles();
				try {
						if((rsTxns != null)){
							//Loop through the list and add rows to Model
							int i =0;
							while(rsTxns.next())
							{
								LicensePlateNumber = rsTxns.getString("LicensePlateNumber");
								Make = rsTxns.getString("Make");
								Year = rsTxns.getString("Year");
								Model = rsTxns.getString("Model");
								Color = rsTxns.getString("Color");
								TagCode = rsTxns.getString("TagCode");

								TxnTableModel.addRow(new Object[]{LicensePlateNumber, Make, Model, Year, Color, TagCode, new JButton("Remove")});
								i++;
							}
						}
					} catch(SQLException e1) {
						System.out.println("SQLException: " + e1);
						while (e != null){
						System.out.println("SQLState: " + e1.getSQLState());
						System.out.println("Message: " + e1.getMessage());
						System.out.println("Vendor: " + e1.getErrorCode());
						e1 = e1.getNextException();
						System.out.println("");
						}

					} catch (Exception e2) {
						System.out.println("Exception: " + e2);
						e2.printStackTrace ();
					}





					/*		}
						}); */

				}


			  /*  Object value = table.getValueAt(row, column);

			    if (value instanceof JButton) {
			    	((JButton)value).doClick();
			    } */


			}
		}


}







	class JTableModel extends AbstractTableModel {
		private static final long serialVersionUID = 1L;
		private static final String[] COLUMN_NAMES = new String[] {"VehicleIdNumber", "Make", "Model", "Year", "color", "TagCode",  "Remove"};
		private static final Class<?>[] COLUMN_TYPES = new Class<?>[] {String.class,String.class,String.class,String.class,JButton.class};

		@Override public int getColumnCount() {
			return COLUMN_NAMES.length;
		}

		@Override public int getRowCount() {
			return 4;
		}

		@Override public String getColumnName(int columnIndex) {
	        return COLUMN_NAMES[columnIndex];
	    }

		@Override public Class<?> getColumnClass(int columnIndex) {
			return COLUMN_TYPES[columnIndex];
		}

		@Override public Object getValueAt(final int rowIndex, final int columnIndex) {
			switch (columnIndex) {
				case 0: return rowIndex;
				case 1: //
				case 2: // fall through
				case 3:
				case 4:
				case 5: final JButton button = new JButton(COLUMN_NAMES[columnIndex]);
						/*button.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent arg0) {
								// Remove Vehicle Code and refresh the Grid


							}
						}); */
						return button;
				default: return "Error";
			}
		}
	}
